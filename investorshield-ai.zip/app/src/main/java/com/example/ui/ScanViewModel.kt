package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.ScanEntity
import com.example.data.database.ThreatIntelligenceEntity
import com.example.data.repository.ScanRepository
import com.example.data.api.Content
import com.example.data.api.Part
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GeminiApiService
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // USER or GEMINI
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class ScanViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = ScanRepository(db.scanDao(), db.threatIntelligenceDao())

    val scans: StateFlow<List<ScanEntity>> = repository.allScans
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val threats: StateFlow<List<ThreatIntelligenceEntity>> = repository.allThreats
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val _scanResult = MutableStateFlow<ScanEntity?>(null)
    val scanResult: StateFlow<ScanEntity?> = _scanResult

    private val _scanningStatus = MutableStateFlow("")
    val scanningStatus: StateFlow<String> = _scanningStatus

    // Chat States
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage(
            sender = "GEMINI",
            text = "Welcome to InvestorShield Compliance Advisor. I can help verify investment offers, explain SEBI regulations, or advise you on how to spot fraudulent stock advisors. What can I check for you today?"
        )
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    private val _isSendingMessage = MutableStateFlow(false)
    val isSendingMessage: StateFlow<Boolean> = _isSendingMessage

    // Trigger dynamic forensic scanning
    fun startScan(
        title: String,
        contentType: String,
        content: String,
        bitmap: Bitmap? = null,
        useWebSearch: Boolean,
        useDeepThinking: Boolean
    ) {
        viewModelScope.launch {
            _isScanning.value = true
            _scanResult.value = null
            
            _scanningStatus.value = "Initializing threat crosscheck..."
            kotlinx.coroutines.delay(400)
            
            _scanningStatus.value = "Consulting offline SEBI registry indicators..."
            kotlinx.coroutines.delay(500)
            
            _scanningStatus.value = if (useDeepThinking) {
                "Assembling reasoning engine with gemini-3.1-pro-preview..."
            } else {
                "Spinning up audit engine with gemini-3.5-flash..."
            }
            kotlinx.coroutines.delay(600)
            
            _scanningStatus.value = if (useWebSearch) {
                "Querying live SEBI lists and financial reputation sources..."
            } else {
                "Performing linguistic forensic scan..."
            }
            
            try {
                val result = repository.scanContent(
                    title = title,
                    contentType = contentType,
                    content = content,
                    bitmap = bitmap,
                    useWebSearch = useWebSearch,
                    useDeepThinking = useDeepThinking
                )
                _scanResult.value = result
            } catch (e: Exception) {
                Log.e("InvestorShield", "Scanning flow crashed", e)
            } finally {
                _isScanning.value = false
                _scanningStatus.value = ""
            }
        }
    }

    fun clearScanResult() {
        _scanResult.value = null
    }

    fun deleteScan(id: String) {
        viewModelScope.launch {
            repository.deleteScanById(id)
        }
    }

    fun clearAllScans() {
        viewModelScope.launch {
            repository.deleteAllScans()
        }
    }

    // Threat intelligence management
    fun addThreatIntel(
        name: String,
        type: String,
        indicator: String,
        severity: String,
        notes: String
    ) {
        viewModelScope.launch {
            val threat = ThreatIntelligenceEntity(
                entityName = name,
                type = type,
                indicator = indicator,
                severity = severity,
                notes = notes
            )
            repository.insertThreat(threat)
        }
    }

    fun deleteThreatIntel(id: String) {
        viewModelScope.launch {
            repository.deleteThreatById(id)
        }
    }

    // Gemini Chatbot Integration
    fun sendChatMessage(text: String) {
        if (text.trim().isEmpty()) return
        
        val userMsg = ChatMessage(sender = "USER", text = text)
        _chatMessages.value = _chatMessages.value + userMsg
        _isSendingMessage.value = true

        viewModelScope.launch {
            val apiKey = BuildConfig.GEMINI_API_KEY
            val apiService = GeminiApiService.create()

            val systemInstruction = """
                You are InvestorShield's Expert AI Compliance Chatbot, specialized in India's financial securities regulatory landscape.
                Your task is to advise retail investors, identify red flags in mutual funds, stock advice, PMS, and IPO subscriptions, and cite SEBI regulations where appropriate.
                Always be objective, clear, and professional. 
                Remind the user never to invest in unregistered advisory services and to always verify registration on the SEBI portal.
            """.trimIndent()

            // Build historical contents array for multi-turn chat
            val chatContents = mutableListOf<Content>()
            _chatMessages.value.takeLast(10).forEach { msg ->
                val role = if (msg.sender == "USER") "user" else "model"
                // Map to the Gemini API structure: we can put "user" or "model" text, but since we are using direct REST API,
                // contents array contains elements of Content with Parts.
                chatContents.add(Content(parts = listOf(Part(text = "${msg.sender}: ${msg.text}"))))
            }

            val request = GenerateContentRequest(
                contents = chatContents,
                systemInstruction = Content(parts = listOf(Part(text = systemInstruction)))
            )

            try {
                val response = apiService.generateContent("gemini-3.5-flash", apiKey, request)
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "I'm having trouble retrieving details. Please ensure you are connected to the internet and check your API keys."
                
                _chatMessages.value = _chatMessages.value + ChatMessage(sender = "GEMINI", text = replyText)
            } catch (e: Exception) {
                Log.e("InvestorShieldChat", "Chat API failed", e)
                _chatMessages.value = _chatMessages.value + ChatMessage(
                    sender = "GEMINI",
                    text = "A connection error occurred. I could not reach the InvestorShield server. Please verify your internet connection. (Error: ${e.localizedMessage})"
                )
            } finally {
                _isSendingMessage.value = false
            }
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = "GEMINI",
                text = "Chat history cleared. How else can I assist you with SEBI compliance or scam detection?"
            )
        )
    }
}
