package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.ThreatIntelligenceEntity
import com.example.ui.ScanViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThreatIntelScreen(
    viewModel: ScanViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val threats by viewModel.threats.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    // Dialog form states
    var entityName by remember { mutableStateOf("") }
    var threatType by remember { mutableStateOf("Fake Advisor") }
    var indicatorText by remember { mutableStateOf("") }
    var severityLevel by remember { mutableStateOf("HIGH") }
    var notesText by remember { mutableStateOf("") }

    val filteredThreats = remember(threats, searchQuery) {
        if (searchQuery.trim().isEmpty()) {
            threats
        } else {
            threats.filter {
                it.entityName.contains(searchQuery, ignoreCase = true) ||
                it.indicator.contains(searchQuery, ignoreCase = true) ||
                it.type.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Threat Intelligence DB",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = PrimaryDark,
                        letterSpacing = (-0.5).sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = PrimaryDark)
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Filled.Add, contentDescription = "Add Threat", tint = PrimaryAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceWhite,
                    scrolledContainerColor = SurfaceWhite
                ),
                modifier = Modifier.border(width = (0.5).dp, color = SlateBorder)
            )
        },
        containerColor = LightBg
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search entity, link, phone, or pattern...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                shape = RoundedCornerShape(14.dp),
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search icon", tint = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryAccent,
                    unfocusedContainerColor = SurfaceWhite,
                    focusedContainerColor = SurfaceWhite
                )
            )

            // Threat List count
            Text(
                text = "${filteredThreats.size} Threat Indicators Monitored",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = SecondarySlate
            )

            // Threat list
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (filteredThreats.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.SearchOff,
                                contentDescription = "Not found",
                                tint = Color.LightGray,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No threats found", fontWeight = FontWeight.Bold, color = PrimaryDark)
                            Text("Try searching another keyword or add a new entry.", fontSize = 12.sp, color = SecondarySlate)
                        }
                    }
                } else {
                    items(filteredThreats) { threat ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceWhite)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .background(
                                                    if (threat.severity == "HIGH") RiskHighLight else RiskMediumLight,
                                                    RoundedCornerShape(6.dp)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (threat.severity == "HIGH") Icons.Filled.Warning else Icons.Filled.Info,
                                                contentDescription = "Threat",
                                                tint = if (threat.severity == "HIGH") RiskHigh else RiskMedium,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = threat.entityName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = PrimaryDark,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.widthIn(max = 200.dp)
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (threat.severity == "HIGH") RiskHighLight else RiskMediumLight,
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = threat.severity,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (threat.severity == "HIGH") RiskHigh else RiskMedium
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(
                                            imageVector = Icons.Filled.DeleteOutline,
                                            contentDescription = "Delete threat",
                                            tint = Color.Gray,
                                            modifier = Modifier
                                                .size(20.dp)
                                                .clickable {
                                                    viewModel.deleteThreatIntel(threat.id)
                                                    Toast.makeText(context, "Threat indicator removed.", Toast.LENGTH_SHORT).show()
                                                }
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = SlateBorder)
                                Spacer(modifier = Modifier.height(10.dp))

                                Row {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("CLASSIFICATION", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                        Text(threat.type, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                                    }
                                    Column(modifier = Modifier.weight(1.5f)) {
                                        Text("DETECTION INDICATOR", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                        Text(threat.indicator, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PrimaryAccent)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text("COMPLIANCE ANALYST NOTES", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text(
                                    text = threat.notes,
                                    fontSize = 11.sp,
                                    color = SecondarySlate,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Threat Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = {
                Text(
                    text = "Add Threat Indicator",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = PrimaryDark
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = entityName,
                        onValueChange = { entityName = it },
                        label = { Text("Scammer / Entity Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = threatType,
                        onValueChange = { threatType = it },
                        label = { Text("Classification Type") },
                        placeholder = { Text("e.g. Phishing Domain, Pump & Dump") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = indicatorText,
                        onValueChange = { indicatorText = it },
                        label = { Text("Forensic Indicator") },
                        placeholder = { Text("e.g. Website URL, UPI, Phone, Telegram link") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        label = { Text("Analyst Verification Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Severity Selector Segment
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Severity:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                        listOf("HIGH", "MEDIUM", "LOW").forEach { s ->
                            Button(
                                onClick = { severityLevel = s },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (severityLevel == s) {
                                        if (s == "HIGH") RiskHigh else if (s == "MEDIUM") RiskMedium else RiskLow
                                    } else Color.LightGray
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(s, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (entityName.trim().isEmpty() || indicatorText.trim().isEmpty()) {
                            Toast.makeText(context, "Please fill in Entity Name and Indicator.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.addThreatIntel(
                            name = entityName,
                            type = threatType,
                            indicator = indicatorText,
                            severity = severityLevel,
                            notes = notesText
                        )
                        Toast.makeText(context, "New Threat registered to local database.", Toast.LENGTH_SHORT).show()
                        showAddDialog = false
                        // Reset fields
                        entityName = ""
                        threatType = "Fake Advisor"
                        indicatorText = ""
                        notesText = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryAccent)
                ) {
                    Text("Register Indicator")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }
}
