package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Minimal Professional Fintech Slate Theme
val PrimaryDark = Color(0xFF0F172A) // slate-900
val PrimaryLight = Color(0xFF1E293B) // slate-800
val PrimaryAccent = Color(0xFF4F46E5) // Indigo-600

val SecondarySlate = Color(0xFF64748B) // slate-500
val SlateBorder = Color(0xFFE2E8F0) // slate-200
val LightBg = Color(0xFFFDFCFB) // clean light minimal background
val SurfaceWhite = Color(0xFFFFFFFF)

// Risk Semantic Colors
val RiskLow = Color(0xFF059669) // emerald-600
val RiskMedium = Color(0xFFD97706) // amber-600
val RiskHigh = Color(0xFFE11D48) // rose-600
val RiskHighLight = Color(0xFFFFF1F2) // rose-50
val RiskMediumLight = Color(0xFFFEF3C7) // amber-50
val RiskLowLight = Color(0xFFECFDF5) // emerald-50
