package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SurfaceWhite,
    secondary = SecondarySlate,
    tertiary = PrimaryAccent,
    background = PrimaryDark,
    surface = PrimaryLight,
    onPrimary = PrimaryDark,
    onSecondary = SurfaceWhite,
    onTertiary = SurfaceWhite,
    onBackground = SurfaceWhite,
    onSurface = SurfaceWhite
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryDark,
    secondary = SecondarySlate,
    tertiary = PrimaryAccent,
    background = LightBg,
    surface = SurfaceWhite,
    onPrimary = Color.White,
    onSecondary = PrimaryDark,
    onTertiary = Color.White,
    onBackground = PrimaryDark,
    onSurface = PrimaryDark
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep it false to preserve our executive fintech branding
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
