package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.ScanEntity
import com.example.ui.ScanViewModel
import com.example.ui.theme.*
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportDetailScreen(
    scanId: String,
    viewModel: ScanViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scans by viewModel.scans.collectAsState()
    
    val scan = remember(scans, scanId) {
        scans.find { it.id == scanId }
    }

    if (scan == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Report not found", color = SecondarySlate)
        }
        return
    }

    val dateString = remember(scan.timestamp) {
        val formatter = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        formatter.format(Date(scan.timestamp))
    }

    val evidenceList = remember(scan.evidenceListJson) {
        val list = mutableListOf<String>()
        try {
            val jsonArray = JSONArray(scan.evidenceListJson)
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
        } catch (e: Exception) {
            list.add("No specific indicators listed.")
        }
        list
    }

    val recommendations = remember(scan.recommendationsJson) {
        val list = mutableListOf<String>()
        try {
            val jsonArray = JSONArray(scan.recommendationsJson)
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
        } catch (e: Exception) {
            list.add("No recommendations available.")
        }
        list
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Forensic Audit Report",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = PrimaryDark,
                        letterSpacing = (-0.5).sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = PrimaryDark)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.deleteScan(scan.id)
                        Toast.makeText(context, "Report deleted from database.", Toast.LENGTH_SHORT).show()
                        onNavigateBack()
                    }) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = RiskHigh)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceWhite,
                    scrolledContainerColor = SurfaceWhite
                ),
                modifier = Modifier.border(width = (0.5).dp, color = SlateBorder)
            )
        },
        containerColor = LightBg
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Core Metadata Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = scan.title.ifEmpty { "Untitled Forensic Scan" },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Audit ID: IS-${scan.id.take(8).uppercase(Locale.ROOT)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.Gray,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(
                                    when (scan.riskLevel) {
                                        "LOW" -> RiskLowLight
                                        "MEDIUM" -> RiskMediumLight
                                        else -> RiskHighLight
                                    },
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${scan.riskLevel} RISK",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (scan.riskLevel) {
                                    "LOW" -> RiskLow
                                    "MEDIUM" -> RiskMedium
                                    else -> RiskHigh
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("AUDIT TIMESTAMP", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                            Text(dateString, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("CONTENT CLASSIFICATION", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                            Text(scan.contentType, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                        }
                    }
                }
            }

            // 2. Risk & Confidence Metrics Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Core Safety Metrics",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PrimaryDark
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Risk Score Dial representation
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .background(
                                        when (scan.riskLevel) {
                                            "LOW" -> RiskLowLight
                                            "MEDIUM" -> RiskMediumLight
                                            else -> RiskHighLight
                                        },
                                        RoundedCornerShape(40.dp)
                                    )
                                    .border(
                                        3.dp,
                                        when (scan.riskLevel) {
                                            "LOW" -> RiskLow
                                            "MEDIUM" -> RiskMedium
                                            else -> RiskHigh
                                        },
                                        RoundedCornerShape(40.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${scan.riskScore}%",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (scan.riskLevel) {
                                        "LOW" -> RiskLow
                                        "MEDIUM" -> RiskMedium
                                        else -> RiskHigh
                                    }
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("RISK SCORE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SecondarySlate)
                        }

                        // Confidence Indicator
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .background(LightBg, RoundedCornerShape(40.dp))
                                    .border(3.dp, PrimaryAccent, RoundedCornerShape(40.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${scan.confidence}%",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryAccent
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("CONFIDENCE LEVEL", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SecondarySlate)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (scan.webSearchUsed) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                                contentDescription = "Web Search Indicator",
                                tint = if (scan.webSearchUsed) RiskLow else Color.LightGray,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Web Grounding Used", fontSize = 11.sp, color = SecondarySlate)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (scan.deepThinkingUsed) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                                contentDescription = "Deep Thinking Indicator",
                                tint = if (scan.deepThinkingUsed) RiskLow else Color.LightGray,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reasoning Engine Engaged", fontSize = 11.sp, color = SecondarySlate)
                        }
                    }
                }
            }

            // 3. Detailed Forensic Explanation Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Audit Analysis Explanation",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = PrimaryDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = scan.explanation,
                        fontSize = 13.sp,
                        color = PrimaryDark,
                        lineHeight = 18.sp
                    )
                }
            }

            // 4. Identified Evidence checklist
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Discovered Risk Evidence",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = PrimaryDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    evidenceList.forEachIndexed { index, evidence ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ReportGmailerrorred,
                                contentDescription = "Warning indicator",
                                tint = if (scan.riskLevel == "HIGH") RiskHigh else RiskMedium,
                                modifier = Modifier
                                    .size(18.dp)
                                    .padding(top = 1.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = evidence,
                                fontSize = 12.sp,
                                color = PrimaryDark,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // 5. Actionable safety recommendations
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Safety Recommendations",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = PrimaryDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    recommendations.forEachIndexed { index, recommendation ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VerifiedUser,
                                contentDescription = "Verified action",
                                tint = RiskLow,
                                modifier = Modifier
                                    .size(18.dp)
                                    .padding(top = 1.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = recommendation,
                                fontSize = 12.sp,
                                color = PrimaryDark,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // 6. Action Bar Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(context, "Signed report link copied to clipboard.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryDark)
                ) {
                    Icon(Icons.Filled.Share, contentDescription = "Share")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share Link", fontSize = 13.sp)
                }

                Button(
                    onClick = {
                        Toast.makeText(context, "PDF generated successfully.", Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryAccent)
                ) {
                    Icon(Icons.Filled.PictureAsPdf, contentDescription = "PDF")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export PDF", fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
