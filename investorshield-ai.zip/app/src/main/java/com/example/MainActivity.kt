package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.ScanViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ScanCenterScreen
import com.example.ui.screens.ReportDetailScreen
import com.example.ui.screens.ThreatIntelScreen
import com.example.ui.screens.ComplianceChatScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val viewModel: ScanViewModel = viewModel()

                    NavHost(
                        navController = navController,
                        startDestination = "dashboard"
                    ) {
                        composable("dashboard") {
                            DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToScan = { navController.navigate("scan") },
                                onNavigateToReport = { id -> navController.navigate("report/$id") },
                                onNavigateToThreats = { navController.navigate("threats") },
                                onNavigateToChat = { navController.navigate("chat") }
                            )
                        }

                        composable("scan") {
                            ScanCenterScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() },
                                onScanComplete = {
                                    val lastScanId = viewModel.scanResult.value?.id
                                    viewModel.clearScanResult()
                                    if (lastScanId != null) {
                                        navController.navigate("report/$lastScanId") {
                                            // Pop up to dashboard so pressing back from report details goes back to dashboard
                                            popUpTo("dashboard")
                                        }
                                    } else {
                                        navController.popBackStack()
                                    }
                                }
                            )
                        }

                        composable(
                            route = "report/{scanId}",
                            arguments = listOf(navArgument("scanId") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val scanId = backStackEntry.arguments?.getString("scanId") ?: ""
                            ReportDetailScreen(
                                scanId = scanId,
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("threats") {
                            ThreatIntelScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("chat") {
                            ComplianceChatScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
