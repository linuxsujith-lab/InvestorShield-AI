package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "threat_intelligence")
data class ThreatIntelligenceEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val entityName: String,
    val type: String, // Fake Advisor, Phishing Domain, Pump & Dump, Scam Pattern
    val indicator: String, // Phone, URL, Telegram link, Text snippet
    val severity: String, // HIGH, MEDIUM, LOW
    val notes: String,
    val timestamp: Long = System.currentTimeMillis()
)
