package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ThreatIntelligenceDao {
    @Query("SELECT * FROM threat_intelligence ORDER BY timestamp DESC")
    fun getAllThreatIntelligence(): Flow<List<ThreatIntelligenceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertThreat(threat: ThreatIntelligenceEntity)

    @Query("DELETE FROM threat_intelligence WHERE id = :id")
    suspend fun deleteThreatById(id: String)

    @Query("SELECT * FROM threat_intelligence WHERE indicator LIKE '%' || :query || '%' OR entityName LIKE '%' || :query || '%'")
    suspend fun searchThreats(query: String): List<ThreatIntelligenceEntity>
}
