package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "scans")
data class ScanEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val contentType: String, // TEXT, SCREENSHOT, AUDIO, URL
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val riskScore: Int, // 0 to 100
    val riskLevel: String, // LOW, MEDIUM, HIGH
    val confidence: Int, // 0 to 100
    val explanation: String,
    val evidenceListJson: String, // JSON array of evidence
    val recommendationsJson: String, // JSON array of recommendations
    val webSearchUsed: Boolean = false,
    val deepThinkingUsed: Boolean = false
)
