package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [ScanEntity::class, ThreatIntelligenceEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scanDao(): ScanDao
    abstract fun threatIntelligenceDao(): ThreatIntelligenceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "investorshield_database"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialThreats(database.threatIntelligenceDao())
                }
            }
        }

        suspend fun populateInitialThreats(dao: ThreatIntelligenceDao) {
            // Populate realistic, highly practical SEBI-adjacent warnings & scam indicators for India's market
            val initialThreats = listOf(
                ThreatIntelligenceEntity(
                    entityName = "Lazard Asset Management Clone",
                    type = "Fake Advisor / Clone Broker",
                    indicator = "http://lazard-wealth-india.cc",
                    severity = "HIGH",
                    notes = "Cloned website mimicking Lazard Asset Management offering guaranteed 300% weekly returns via fake WhatsApp groups."
                ),
                ThreatIntelligenceEntity(
                    entityName = "SEBI Impersonation WhatsApp Scam",
                    type = "Scam Pattern",
                    indicator = "SEBI Executive Club",
                    severity = "HIGH",
                    notes = "Telegram / WhatsApp groups posing as official SEBI regulatory officers offering 'institutional quota' IPO allocations."
                ),
                ThreatIntelligenceEntity(
                    entityName = "SMC Global Trading Clone",
                    type = "Phishing Domain",
                    indicator = "https://smc-global-shares-online.com",
                    severity = "HIGH",
                    notes = "Phishing portal trying to steal credentials of SMC Global Securities retail clients."
                ),
                ThreatIntelligenceEntity(
                    entityName = "Groww Mutual Fund Impersonator",
                    type = "Fake Advisor",
                    indicator = "+91 8899001122",
                    severity = "HIGH",
                    notes = "Fake Groww support agents asking for OTPs or urging users to transfer funds to personal UPI handles."
                ),
                ThreatIntelligenceEntity(
                    entityName = "High-Yield Crypto Trading Tip Group",
                    type = "Pump & Dump",
                    indicator = "t.me/sebi_approved_wealth",
                    severity = "HIGH",
                    notes = "Large Telegram group of 50k+ fake members promoting unregulated high-yield micro-cap options recommendations."
                )
            )
            for (threat in initialThreats) {
                dao.insertThreat(threat)
            }
        }
    }
}
