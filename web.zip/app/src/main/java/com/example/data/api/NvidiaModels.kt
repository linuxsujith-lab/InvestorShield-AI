package com.example.data.api

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class NvidiaChatRequest(
    val model: String = "google/gemma-3n-e2b-it",
    val messages: List<NvidiaMessage>,
    val max_tokens: Int = 1024,
    val temperature: Float = 0.2f,
    val top_p: Float = 0.7f,
    val frequency_penalty: Float = 0.0f,
    val presence_penalty: Float = 0.0f,
    val stream: Boolean = false
)

@JsonClass(generateAdapter = true)
data class NvidiaMessage(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class NvidiaChatResponse(
    val choices: List<NvidiaChoice>?
)

@JsonClass(generateAdapter = true)
data class NvidiaChoice(
    val message: NvidiaMessage?
)

@JsonClass(generateAdapter = true)
data class SebiNewsItem(
    val title: String,
    val category: String, // e.g., Advisory, Warning, Circular, Press Release
    val date: String,
    val content: String,
    val impact: String,
    val severity: String // Low, Medium, High
)
