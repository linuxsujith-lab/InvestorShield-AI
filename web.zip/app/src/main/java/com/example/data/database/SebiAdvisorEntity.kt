package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sebi_advisors")
data class SebiAdvisorEntity(
    @PrimaryKey val registrationNumber: String, // e.g. INA000012345
    val name: String,
    val type: String, // e.g. Investment Adviser (RIA), Research Analyst (RA), Portfolio Manager (PMS)
    val status: String, // e.g. ACTIVE, SUSPENDED, EXPIRED, UNREGISTERED
    val validUntil: String,
    val address: String,
    val contactEmail: String,
    val advisoryScope: String // Details about what they are authorized to do
)
