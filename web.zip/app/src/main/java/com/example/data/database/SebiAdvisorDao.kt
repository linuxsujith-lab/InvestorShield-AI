package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SebiAdvisorDao {
    @Query("SELECT * FROM sebi_advisors ORDER BY name ASC")
    fun getAllAdvisors(): Flow<List<SebiAdvisorEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdvisor(advisor: SebiAdvisorEntity)

    @Query("SELECT * FROM sebi_advisors WHERE UPPER(registrationNumber) = UPPER(:query) OR UPPER(name) LIKE '%' || UPPER(:query) || '%' LIMIT 1")
    suspend fun lookupAdvisor(query: String): SebiAdvisorEntity?

    @Query("SELECT * FROM sebi_advisors WHERE UPPER(registrationNumber) LIKE '%' || UPPER(:query) || '%' OR UPPER(name) LIKE '%' || UPPER(:query) || '%'")
    suspend fun searchAdvisors(query: String): List<SebiAdvisorEntity>
}
