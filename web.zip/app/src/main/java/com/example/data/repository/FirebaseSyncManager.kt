package com.example.data.repository

import android.content.Context
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.database.ScanEntity
import com.example.data.database.ThreatIntelligenceEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.util.concurrent.TimeUnit
import org.json.JSONObject

enum class SyncState {
    IDLE, SYNCING, SUCCESS, ERROR
}

data class UserProfile(
    val uid: String,
    val name: String,
    val email: String,
    val role: String,
    val bio: String,
    val totalScans: Int,
    val criticalThreats: Int,
    val riskProtectionScore: Int
)

class FirebaseSyncManager private constructor() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val _syncState = MutableStateFlow(SyncState.IDLE)
    val syncState: StateFlow<SyncState> = _syncState

    private val _lastSyncTime = MutableStateFlow<Long>(0)
    val lastSyncTime: StateFlow<Long> = _lastSyncTime

    companion object {
        @Volatile
        private var instance: FirebaseSyncManager? = null

        fun getInstance(): FirebaseSyncManager {
            return instance ?: synchronized(this) {
                instance ?: FirebaseSyncManager().also { instance = it }
            }
        }
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }

    private fun generateJwt(clientEmail: String, privateKeyPem: String): String {
        val now = System.currentTimeMillis() / 1000
        val exp = now + 3600

        val headerJson = "{\"alg\":\"RS256\",\"typ\":\"JWT\"}"
        val claimsJson = """
            {
              "iss": "$clientEmail",
              "scope": "https://www.googleapis.com/auth/datastore",
              "aud": "https://oauth2.googleapis.com/token",
              "exp": $exp,
              "iat": $now
            }
        """.trimIndent()

        val headerBase64 = Base64.encodeToString(headerJson.toByteArray(), Base64.NO_WRAP or Base64.NO_PADDING or Base64.URL_SAFE).trim()
        val claimsBase64 = Base64.encodeToString(claimsJson.toByteArray(), Base64.NO_WRAP or Base64.NO_PADDING or Base64.URL_SAFE).trim()

        val unsignedToken = "$headerBase64.$claimsBase64"

        // Clean up private key PEM
        val pkcs8Pem = privateKeyPem
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("\\s".toRegex(), "")
            .replace("\\n", "")
            .replace("\n", "")
            .replace("\"", "")

        val privateKeyBytes = Base64.decode(pkcs8Pem, Base64.DEFAULT)
        val keySpec = PKCS8EncodedKeySpec(privateKeyBytes)
        val kf = KeyFactory.getInstance("RSA")
        val privateKey = kf.generatePrivate(keySpec)

        val signature = Signature.getInstance("SHA256withRSA")
        signature.initSign(privateKey)
        signature.update(unsignedToken.toByteArray())
        val signatureBytes = signature.sign()

        val signatureBase64 = Base64.encodeToString(signatureBytes, Base64.NO_WRAP or Base64.NO_PADDING or Base64.URL_SAFE).trim()

        return "$unsignedToken.$signatureBase64"
    }

    private suspend fun getAccessToken(): String? = withContext(Dispatchers.IO) {
        try {
            val projectId = BuildConfig.FIREBASE_PROJECT_ID
            val clientEmail = BuildConfig.FIREBASE_CLIENT_EMAIL
            val privateKey = BuildConfig.FIREBASE_PRIVATE_KEY

            if (projectId.isEmpty() || clientEmail.isEmpty() || privateKey.isEmpty() || privateKey == "YOUR_FIREBASE_PRIVATE_KEY") {
                Log.w("FirebaseSync", "Firebase credentials not fully configured in secrets.")
                return@withContext null
            }

            val jwt = generateJwt(clientEmail, privateKey)
            val requestBody = FormBody.Builder()
                .add("grant_type", "urn:ietf:params:oauth:grant-type:jwt-bearer")
                .add("assertion", jwt)
                .build()

            val request = Request.Builder()
                .url("https://oauth2.googleapis.com/token")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("FirebaseSync", "OAuth Token request failed: ${response.code} - ${response.body?.string()}")
                    return@withContext null
                }
                val responseBody = response.body?.string() ?: return@withContext null
                val match = "\"access_token\"\\s*:\\s*\"([^\"]+)\"".toRegex().find(responseBody)
                return@withContext match?.groupValues?.get(1)
            }
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Failed to retrieve access token", e)
            return@withContext null
        }
    }

    suspend fun syncData(scans: List<ScanEntity>, threats: List<ThreatIntelligenceEntity>): Boolean = withContext(Dispatchers.IO) {
        _syncState.value = SyncState.SYNCING
        try {
            val projectId = BuildConfig.FIREBASE_PROJECT_ID
            if (projectId.isEmpty() || projectId == "YOUR_FIREBASE_PROJECT_ID") {
                Log.w("FirebaseSync", "Cannot sync: Project ID is empty")
                _syncState.value = SyncState.ERROR
                return@withContext false
            }

            val token = getAccessToken()
            if (token == null) {
                Log.e("FirebaseSync", "Could not obtain Firebase authentication token")
                _syncState.value = SyncState.ERROR
                return@withContext false
            }

            val jsonMediaType = "application/json; charset=utf-8".toMediaType()

            // 1. Sync Scans to Firestore
            for (scan in scans) {
                val scanJson = """
                    {
                      "fields": {
                        "id": { "stringValue": "${scan.id}" },
                        "title": { "stringValue": "${escapeJson(scan.title)}" },
                        "contentType": { "stringValue": "${scan.contentType}" },
                        "content": { "stringValue": "${escapeJson(scan.content)}" },
                        "timestamp": { "integerValue": "${scan.timestamp}" },
                        "riskScore": { "integerValue": "${scan.riskScore}" },
                        "riskLevel": { "stringValue": "${scan.riskLevel}" },
                        "confidence": { "integerValue": "${scan.confidence}" },
                        "explanation": { "stringValue": "${escapeJson(scan.explanation)}" },
                        "evidenceListJson": { "stringValue": "${escapeJson(scan.evidenceListJson)}" },
                        "recommendationsJson": { "stringValue": "${escapeJson(scan.recommendationsJson)}" },
                        "webSearchUsed": { "booleanValue": ${scan.webSearchUsed} },
                        "deepThinkingUsed": { "booleanValue": ${scan.deepThinkingUsed} }
                      }
                    }
                """.trimIndent()

                val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/scans/${scan.id}"
                val request = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .patch(scanJson.toRequestBody(jsonMediaType))
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.e("FirebaseSync", "Failed to sync scan ${scan.id}: ${response.code} - ${response.body?.string()}")
                    }
                }
            }

            // 2. Sync Threats to Firestore
            for (threat in threats) {
                val threatJson = """
                    {
                      "fields": {
                        "id": { "stringValue": "${threat.id}" },
                        "entityName": { "stringValue": "${escapeJson(threat.entityName)}" },
                        "type": { "stringValue": "${threat.type}" },
                        "indicator": { "stringValue": "${escapeJson(threat.indicator)}" },
                        "severity": { "stringValue": "${threat.severity}" },
                        "notes": { "stringValue": "${escapeJson(threat.notes)}" },
                        "timestamp": { "integerValue": "${threat.timestamp}" }
                      }
                    }
                """.trimIndent()

                val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/threats/${threat.id}"
                val request = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .patch(threatJson.toRequestBody(jsonMediaType))
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.e("FirebaseSync", "Failed to sync threat ${threat.id}: ${response.code} - ${response.body?.string()}")
                    }
                }
            }

            _lastSyncTime.value = System.currentTimeMillis()
            _syncState.value = SyncState.SUCCESS
            return@withContext true
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Error during synchronization", e)
            _syncState.value = SyncState.ERROR
            return@withContext false
        }
    }

    suspend fun fetchUserProfile(uid: String): UserProfile? = withContext(Dispatchers.IO) {
        try {
            val projectId = BuildConfig.FIREBASE_PROJECT_ID
            if (projectId.isEmpty() || projectId == "YOUR_FIREBASE_PROJECT_ID") {
                return@withContext null
            }
            val token = getAccessToken() ?: return@withContext null
            
            val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/users/$uid"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.w("FirebaseSync", "Failed to fetch user profile, code: ${response.code}")
                    return@withContext null
                }
                val bodyStr = response.body?.string() ?: return@withContext null
                val json = JSONObject(bodyStr)
                val fields = json.optJSONObject("fields") ?: return@withContext null
                
                val name = fields.optJSONObject("name")?.optString("stringValue") ?: "Aivo Sujith"
                val email = fields.optJSONObject("email")?.optString("stringValue") ?: "aivosujith@gmail.com"
                val role = fields.optJSONObject("role")?.optString("stringValue") ?: "Executive Account"
                val bio = fields.optJSONObject("bio")?.optString("stringValue") ?: "Enterprise security researcher and retail investor protecting financial portfolios from bad actors."
                val totalScans = fields.optJSONObject("totalScans")?.optString("integerValue")?.toIntOrNull() 
                    ?: fields.optJSONObject("totalScans")?.optInt("integerValue", 124) ?: 124
                val criticalThreats = fields.optJSONObject("criticalThreats")?.optString("integerValue")?.toIntOrNull()
                    ?: fields.optJSONObject("criticalThreats")?.optInt("integerValue", 8) ?: 8
                val riskProtectionScore = fields.optJSONObject("riskProtectionScore")?.optString("integerValue")?.toIntOrNull()
                    ?: fields.optJSONObject("riskProtectionScore")?.optInt("integerValue", 94) ?: 94

                return@withContext UserProfile(
                    uid = uid,
                    name = name,
                    email = email,
                    role = role,
                    bio = bio,
                    totalScans = totalScans,
                    criticalThreats = criticalThreats,
                    riskProtectionScore = riskProtectionScore
                )
            }
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Error fetching user profile", e)
            return@withContext null
        }
    }

    suspend fun saveUserProfile(profile: UserProfile): Boolean = withContext(Dispatchers.IO) {
        try {
            val projectId = BuildConfig.FIREBASE_PROJECT_ID
            if (projectId.isEmpty() || projectId == "YOUR_FIREBASE_PROJECT_ID") {
                return@withContext false
            }
            val token = getAccessToken() ?: return@withContext false
            val jsonMediaType = "application/json; charset=utf-8".toMediaType()

            val userJson = """
                {
                  "fields": {
                    "uid": { "stringValue": "${profile.uid}" },
                    "name": { "stringValue": "${escapeJson(profile.name)}" },
                    "email": { "stringValue": "${escapeJson(profile.email)}" },
                    "role": { "stringValue": "${escapeJson(profile.role)}" },
                    "bio": { "stringValue": "${escapeJson(profile.bio)}" },
                    "totalScans": { "integerValue": "${profile.totalScans}" },
                    "criticalThreats": { "integerValue": "${profile.criticalThreats}" },
                    "riskProtectionScore": { "integerValue": "${profile.riskProtectionScore}" }
                  }
                }
            """.trimIndent()

            val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/users/${profile.uid}"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .patch(userJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("FirebaseSync", "Failed to save user profile: ${response.code} - ${response.body?.string()}")
                    return@withContext false
                }
                return@withContext true
            }
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Error saving user profile", e)
            return@withContext false
        }
    }
}
