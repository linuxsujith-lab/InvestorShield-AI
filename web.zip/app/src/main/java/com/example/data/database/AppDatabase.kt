package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [ScanEntity::class, ThreatIntelligenceEntity::class, SebiAdvisorEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scanDao(): ScanDao
    abstract fun threatIntelligenceDao(): ThreatIntelligenceDao
    abstract fun sebiAdvisorDao(): SebiAdvisorDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "investorshield_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(AppDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialThreats(database.threatIntelligenceDao())
                    populateInitialAdvisors(database.sebiAdvisorDao())
                }
            }
        }

        suspend fun populateInitialAdvisors(dao: SebiAdvisorDao) {
            val initialAdvisors = listOf(
                SebiAdvisorEntity(
                    registrationNumber = "INA100009876",
                    name = "Aivo Sujith Wealth Advisory",
                    type = "Investment Adviser (RIA)",
                    status = "ACTIVE",
                    validUntil = "2032-12-31",
                    address = "Plot No. 45, Tech Zone, Electronic City, Bengaluru, Karnataka, 560100",
                    contactEmail = "sujith.advisory@gmail.com",
                    advisoryScope = "Retail wealth planning, mutual fund allocation, fee-only financial plans."
                ),
                SebiAdvisorEntity(
                    registrationNumber = "INA200005432",
                    name = "Capital Shield Wealth RIA",
                    type = "Investment Adviser (RIA)",
                    status = "ACTIVE",
                    validUntil = "2030-05-15",
                    address = "12th Floor, Maker Chambers V, Nariman Point, Mumbai, Maharashtra, 400021",
                    contactEmail = "info@capitalshield.in",
                    advisoryScope = "High Net Worth Individual (HNI) asset management and SEBI compliant derivatives consulting."
                ),
                SebiAdvisorEntity(
                    registrationNumber = "INH000011223",
                    name = "Sujith Research Analyst Services",
                    type = "Research Analyst (RA)",
                    status = "ACTIVE",
                    validUntil = "2029-09-24",
                    address = "MIG-28, Sector 4, MVP Colony, Visakhapatnam, Andhra Pradesh, 530017",
                    contactEmail = "research@sujithra.com",
                    advisoryScope = "Equities research reports, sector analyses, and corporate governance reviews."
                ),
                SebiAdvisorEntity(
                    registrationNumber = "INZ000031633",
                    name = "Zerodha Broking Limited",
                    type = "Stock Broker (SB)",
                    status = "ACTIVE",
                    validUntil = "PERPETUAL",
                    address = "#153/154, 4th Cross, Dollars Colony, JP Nagar 4th Phase, Bengaluru, 560078",
                    contactEmail = "compliance@zerodha.com",
                    advisoryScope = "Retail stock brokerage, depository participant services, and mutual fund distributions."
                ),
                SebiAdvisorEntity(
                    registrationNumber = "INP000004455",
                    name = "Lazard Asset Management India Private Limited",
                    type = "Portfolio Manager (PMS)",
                    status = "ACTIVE",
                    validUntil = "2035-01-01",
                    address = "Level 8, Vibgyor Towers, Bandra Kurla Complex, Mumbai, 400051",
                    contactEmail = "compliance.india@lazard.com",
                    advisoryScope = "Discretionary and non-discretionary portfolio management services for institutional clients."
                ),
                SebiAdvisorEntity(
                    registrationNumber = "INA200008117",
                    name = "Groww InvestTech Private Limited",
                    type = "Investment Adviser (RIA)",
                    status = "ACTIVE",
                    validUntil = "2031-11-20",
                    address = "No. 11, Promontory Road, Banashankari 3rd Stage, Bengaluru, 560085",
                    contactEmail = "ria-compliance@groww.in",
                    advisoryScope = "Digital direct mutual fund advisory and automated goal-based model portfolios."
                ),
                SebiAdvisorEntity(
                    registrationNumber = "INA300001234",
                    name = "Elite Capital Wealth Advisors",
                    type = "Investment Adviser (RIA)",
                    status = "SUSPENDED",
                    validUntil = "2027-04-18",
                    address = "Block C, Connaught Place, New Delhi, 110001",
                    contactEmail = "contact@elitecapital.in",
                    advisoryScope = "Suspended due to non-compliance with client fee caps under SEBI (Investment Advisers) Regulations, 2013."
                ),
                SebiAdvisorEntity(
                    registrationNumber = "INA400007890",
                    name = "Vintage Market Gurus",
                    type = "Research Analyst (RA)",
                    status = "EXPIRED",
                    validUntil = "2024-03-31",
                    address = "33, Salt Lake Sector V, Kolkata, West Bengal, 700091",
                    contactEmail = "compliance@vintagemarket.in",
                    advisoryScope = "License expired. No longer authorized to issue stock recommendations or equity research reports."
                )
            )
            for (advisor in initialAdvisors) {
                dao.insertAdvisor(advisor)
            }
        }

        suspend fun populateInitialThreats(dao: ThreatIntelligenceDao) {
            // Populate realistic, highly practical SEBI-adjacent warnings & scam indicators for India's market
            val initialThreats = listOf(
                ThreatIntelligenceEntity(
                    entityName = "Lazard Asset Management Clone",
                    type = "Fake Advisor / Clone Broker",
                    indicator = "http://lazard-wealth-india.cc",
                    severity = "HIGH",
                    notes = "Cloned website mimicking Lazard Asset Management offering guaranteed 300% weekly returns via fake WhatsApp groups."
                ),
                ThreatIntelligenceEntity(
                    entityName = "SEBI Impersonation WhatsApp Scam",
                    type = "Scam Pattern",
                    indicator = "SEBI Executive Club",
                    severity = "HIGH",
                    notes = "Telegram / WhatsApp groups posing as official SEBI regulatory officers offering 'institutional quota' IPO allocations."
                ),
                ThreatIntelligenceEntity(
                    entityName = "SMC Global Trading Clone",
                    type = "Phishing Domain",
                    indicator = "https://smc-global-shares-online.com",
                    severity = "HIGH",
                    notes = "Phishing portal trying to steal credentials of SMC Global Securities retail clients."
                ),
                ThreatIntelligenceEntity(
                    entityName = "Groww Mutual Fund Impersonator",
                    type = "Fake Advisor",
                    indicator = "+91 8899001122",
                    severity = "HIGH",
                    notes = "Fake Groww support agents asking for OTPs or urging users to transfer funds to personal UPI handles."
                ),
                ThreatIntelligenceEntity(
                    entityName = "High-Yield Crypto Trading Tip Group",
                    type = "Pump & Dump",
                    indicator = "t.me/sebi_approved_wealth",
                    severity = "HIGH",
                    notes = "Large Telegram group of 50k+ fake members promoting unregulated high-yield micro-cap options recommendations."
                )
            )
            for (threat in initialThreats) {
                dao.insertThreat(threat)
            }
        }
    }
}
