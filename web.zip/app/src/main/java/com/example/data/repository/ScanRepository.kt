package com.example.data.repository

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.data.api.*
import com.example.data.database.ScanDao
import com.example.data.database.ScanEntity
import com.example.data.database.ThreatIntelligenceDao
import com.example.data.database.ThreatIntelligenceEntity
import com.example.data.database.SebiAdvisorDao
import com.example.data.database.SebiAdvisorEntity
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class ScanRepository(
    private val scanDao: ScanDao,
    private val threatDao: ThreatIntelligenceDao,
    private val sebiAdvisorDao: SebiAdvisorDao,
    private val apiService: GeminiApiService = GeminiApiService.create(),
    private val nvidiaService: NvidiaApiService = NvidiaApiService.create()
) {
    val allScans: Flow<List<ScanEntity>> = scanDao.getAllScans()
    val allThreats: Flow<List<ThreatIntelligenceEntity>> = threatDao.getAllThreatIntelligence()
    val allAdvisors: Flow<List<SebiAdvisorEntity>> = sebiAdvisorDao.getAllAdvisors()

    suspend fun lookupAdvisor(query: String): SebiAdvisorEntity? = withContext(Dispatchers.IO) {
        sebiAdvisorDao.lookupAdvisor(query)
    }

    suspend fun searchAdvisors(query: String): List<SebiAdvisorEntity> = withContext(Dispatchers.IO) {
        sebiAdvisorDao.searchAdvisors(query)
    }

    suspend fun insertAdvisor(advisor: SebiAdvisorEntity) = withContext(Dispatchers.IO) {
        sebiAdvisorDao.insertAdvisor(advisor)
    }

    suspend fun getScanById(id: String): ScanEntity? = withContext(Dispatchers.IO) {
        scanDao.getScanById(id)
    }

    suspend fun insertScan(scan: ScanEntity) = withContext(Dispatchers.IO) {
        scanDao.insertScan(scan)
    }

    suspend fun deleteScanById(id: String) = withContext(Dispatchers.IO) {
        scanDao.deleteScanById(id)
    }

    suspend fun deleteAllScans() = withContext(Dispatchers.IO) {
        scanDao.deleteAllScans()
    }

    suspend fun insertThreat(threat: ThreatIntelligenceEntity) = withContext(Dispatchers.IO) {
        threatDao.insertThreat(threat)
    }

    suspend fun deleteThreatById(id: String) = withContext(Dispatchers.IO) {
        threatDao.deleteThreatById(id)
    }

    // High fidelity Scan Content function Orchestrating Local DB + Gemini AI
    suspend fun scanContent(
        title: String,
        contentType: String,
        content: String,
        bitmap: Bitmap? = null,
        useWebSearch: Boolean,
        useDeepThinking: Boolean
    ): ScanEntity = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e("InvestorShield", "Gemini API key is not configured.")
        }

        // 1. Cross-reference local threat intelligence database first
        val matchingThreats = mutableListOf<ThreatIntelligenceEntity>()
        try {
            val allLocalThreats = threatDao.searchThreats("") // Get all
            for (threat in allLocalThreats) {
                // If the indicator (link, phone, group name) is contained in the content (case insensitive)
                if (threat.indicator.isNotEmpty() && content.contains(threat.indicator, ignoreCase = true)) {
                    matchingThreats.add(threat)
                }
            }
        } catch (e: Exception) {
            Log.e("InvestorShield", "Error checking local threats", e)
        }

        // 2. Select appropriate model based on capabilities
        // - Deep Thinking uses gemini-3.1-pro-preview
        // - General text or image verification uses gemini-3.5-flash
        val model = if (useDeepThinking) "gemini-3.1-pro-preview" else "gemini-3.5-flash"

        // 3. Build system instructions with local context inject
        val localContextPrompt = if (matchingThreats.isNotEmpty()) {
            val threatsString = matchingThreats.joinToString("\n") { 
                "- [MATCHED FLAG] Entity: ${it.entityName}, Type: ${it.type}, Indicator: ${it.indicator}, Severity: ${it.severity}. Notes: ${it.notes}"
            }
            "\nCRITICAL: Our offline Threat Intelligence Database matched the following registered scams in this content:\n$threatsString\nYou MUST heavily incorporate these matched flags, elevate the risk score, and explain this connection in your report."
        } else {
            ""
        }

        val systemInstructionText = """
            You are an expert SEBI-registered compliance auditor and cybersecurity forensic investigator protecting retail investors in India's securities market.
            Your task is to analyze the user's submitted financial communication (text, social media post, image/screenshot, audio transcript, or URL) for fraud, scams, phishing, fake stock advisors, pump-and-dump schemes, and unregistered investment advisors.
            $localContextPrompt

            You MUST analyze the communication thoroughly. Look for:
            - Unrealistic guaranteed returns (e.g., 20% daily, 300% weekly).
            - Unregistered advisors operating on Telegram, WhatsApp, or YouTube.
            - Phishing URLs posing as real Indian stock brokers (Zerodha, Groww, AngelOne, SMC, etc.).
            - Pressure tactics or artificial urgency.
            - Pump-and-dump behavior of illiquid penny stocks.
            - Impersonation of licensed SEBI professionals or international funds.

            You MUST respond strictly with a valid JSON object matching this schema:
            {
              "riskScore": Int (0 to 100 where 100 is extremely dangerous fraud/scam),
              "riskLevel": "LOW" | "MEDIUM" | "HIGH",
              "confidence": Int (0 to 100, indicating your confidence in this analysis),
              "explanation": "Clear, detailed explanation of your analysis, highlighting regulatory violations like SEBI regulations and guidelines.",
              "evidence": ["Evidence 1", "Evidence 2", ...],
              "recommendations": ["Recommendation 1", "Recommendation 2", ...]
            }

            Do NOT wrap the JSON in markdown code blocks like ```json ... ```. Output ONLY the raw JSON text.
        """.trimIndent()

        // 4. Construct content parts (Text)
        val promptContent = buildString {
            append("Content to analyze:\nTitle: $title\nType: $contentType\nContent: $content")
            if (bitmap != null) {
                append("\n(An image/screenshot attachment was uploaded for review by the user)")
            }
        }

        // 5. Build Nvidia Request
        val nvidiaMessages = listOf(
            NvidiaMessage(role = "system", content = systemInstructionText),
            NvidiaMessage(role = "user", content = promptContent)
        )

        val nvidiaRequest = NvidiaChatRequest(
            model = "google/gemma-3n-e2b-it",
            messages = nvidiaMessages,
            max_tokens = 1024,
            temperature = 0.20f,
            top_p = 0.70f,
            frequency_penalty = 0.00f,
            presence_penalty = 0.00f,
            stream = false
        )

        // 6. Make Network Call with fallback for safety
        var riskScore = 15
        var riskLevel = "LOW"
        var confidence = 90
        var explanation = "Analysis successfully completed locally. No severe indicators were found in the plain text."
        val evidence = mutableListOf<String>()
        val recommendations = mutableListOf<String>()

        if (matchingThreats.isNotEmpty()) {
            riskScore = 85
            riskLevel = "HIGH"
            explanation = "WARNING: Match found in the offline SEBI Threat Intelligence Database. This communication contains indicators tied to a known scam: ${matchingThreats.first().entityName}."
            matchingThreats.forEach {
                evidence.add("Offline threat match: ${it.entityName} (${it.type})")
                recommendations.add("Do NOT click any link or send funds to UPI/bank handles associated with ${it.indicator}.")
            }
        }

        try {
            val authHeader = "Bearer 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"
            val response = nvidiaService.chatCompletions(authHeader, request = nvidiaRequest)
            val responseText = response.choices?.firstOrNull()?.message?.content
            if (!responseText.isNullOrEmpty()) {
                Log.d("InvestorShield", "Nvidia response text: $responseText")
                // Sometimes models wrap JSON in markdown blocks like ```json ... ```, let's extract it if present
                var cleanText = responseText.trim()
                if (cleanText.startsWith("```")) {
                    cleanText = cleanText.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                }
                val json = JSONObject(cleanText)
                riskScore = json.optInt("riskScore", riskScore)
                riskLevel = json.optString("riskLevel", riskLevel)
                confidence = json.optInt("confidence", confidence)
                explanation = json.optString("explanation", explanation)

                evidence.clear()
                val evidenceArray = json.optJSONArray("evidence")
                if (evidenceArray != null) {
                    for (i in 0 until evidenceArray.length()) {
                        evidence.add(evidenceArray.getString(i))
                    }
                }

                recommendations.clear()
                val recsArray = json.optJSONArray("recommendations")
                if (recsArray != null) {
                    for (i in 0 until recsArray.length()) {
                        recommendations.add(recsArray.getString(i))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("InvestorShield", "Nvidia API analysis failed, using local/fallback evaluation", e)
            if (matchingThreats.isEmpty()) {
                explanation = "A network error occurred while performing live AI audit. Local safety rules applied: Be cautious of unsolicited financial offers over Telegram/WhatsApp. Error: ${e.localizedMessage}"
                evidence.add("Live network audit failed - completed with local heuristics")
                recommendations.add("Verify any advisor on the SEBI portal before acting.")
            }
        }

        if (evidence.isEmpty()) {
            evidence.add("No immediate threat matching known templates.")
        }
        if (recommendations.isEmpty()) {
            recommendations.add("Always verify SEBI registration numbers on the official SEBI portal.")
        }

        // 7. Store Result and Return
        val finalScan = ScanEntity(
            title = title,
            contentType = contentType,
            content = content,
            riskScore = riskScore,
            riskLevel = riskLevel,
            confidence = confidence,
            explanation = explanation,
            evidenceListJson = JSONArray(evidence).toString(),
            recommendationsJson = JSONArray(recommendations).toString(),
            webSearchUsed = useWebSearch,
            deepThinkingUsed = useDeepThinking
        )

        scanDao.insertScan(finalScan)
        finalScan
    }

    // Helper to convert Bitmap to Base64 jpeg
    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        this.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
