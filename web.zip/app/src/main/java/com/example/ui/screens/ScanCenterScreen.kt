package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ScanViewModel
import com.example.ui.theme.*
import java.io.File
import java.io.InputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanCenterScreen(
    viewModel: ScanViewModel,
    onNavigateBack: () -> Unit,
    onScanComplete: () -> Unit
) {
    val context = LocalContext.current
    val isScanning by viewModel.isScanning.collectAsState()
    val scanResult by viewModel.scanResult.collectAsState()
    val scanningStatus by viewModel.scanningStatus.collectAsState()

    var selectedType by remember { mutableStateOf("TEXT") } // TEXT, URL, SCREENSHOT, AUDIO
    var title by remember { mutableStateOf("") }
    var contentText by remember { mutableStateOf("") }
    var urlText by remember { mutableStateOf("") }

    // Advanced settings
    var useWebSearch by remember { mutableStateOf(false) }
    var useDeepThinking by remember { mutableStateOf(false) }

    // Screenshot scan states
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                selectedBitmap = bitmap
                Toast.makeText(context, "Image imported successfully.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load image: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Audio recording states
    var isRecording by remember { mutableStateOf(false) }
    var audioFile by remember { mutableStateOf<File?>(null) }
    var mediaRecorder by remember { mutableStateOf<MediaRecorder?>(null) }

    // Audio record permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            // Permission granted, start recording
            try {
                val file = File(context.cacheDir, "investorshield_voice_${System.currentTimeMillis()}.3gp")
                audioFile = file
                
                @Suppress("DEPRECATION")
                val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    MediaRecorder()
                }
                
                recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
                recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                recorder.setOutputFile(file.absolutePath)
                recorder.prepare()
                recorder.start()
                
                mediaRecorder = recorder
                isRecording = true
                Toast.makeText(context, "Recording started. Speak to capture advice...", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Could not start recorder: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(context, "Microphone permission is required to analyze audio.", Toast.LENGTH_LONG).show()
        }
    }

    // Handle completed scan transition
    LaunchedEffect(scanResult) {
        if (scanResult != null) {
            onScanComplete()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Forensic Scan Center",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = PrimaryDark,
                        letterSpacing = (-0.5).sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = PrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceWhite,
                    scrolledContainerColor = SurfaceWhite
                ),
                modifier = Modifier.border(width = (0.5).dp, color = SlateBorder)
            )
        },
        containerColor = LightBg
    ) { paddingValues ->
        if (isScanning) {
            // Scanning Loading Screen
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(LightBg)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .background(SurfaceWhite, RoundedCornerShape(16.dp))
                        .border(1.dp, SlateBorder, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = PrimaryAccent,
                        strokeWidth = 4.dp,
                        modifier = Modifier.size(60.dp)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Running Security Audit",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = PrimaryDark
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = scanningStatus,
                    fontSize = 13.sp,
                    color = SecondarySlate,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(modifier = Modifier.height(32.dp))
                Text(
                    text = "Analyzing cryptographic patterns, linguistic indicators, and verifying compliance credentials using Google Gemini API...",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(horizontal = 24.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            // Standard input screen
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Selector Segmented Buttons
                Text(
                    text = "Select Content Source",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = PrimaryDark
                )

                 Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(16.dp))
                        .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        "TEXT" to Icons.Filled.Notes,
                        "URL" to Icons.Filled.Language,
                        "SCREENSHOT" to Icons.Filled.Screenshot,
                        "AUDIO" to Icons.Filled.Mic,
                        "LOOKUP" to Icons.Filled.Search
                    ).forEach { (type, icon) ->
                        val isSelected = selectedType == type
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) SurfaceWhite else Color.Transparent)
                                .then(
                                    if (isSelected) Modifier.border(0.5.dp, SlateBorder, RoundedCornerShape(12.dp))
                                    else Modifier
                                )
                                .clickable { selectedType = type }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = type,
                                    tint = if (isSelected) PrimaryDark else SecondarySlate,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = when (type) {
                                        "TEXT" -> "Text"
                                        "URL" -> "URL"
                                        "SCREENSHOT" -> "Image"
                                        "AUDIO" -> "Audio"
                                        "LOOKUP" -> "Lookup"
                                        else -> type
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) PrimaryDark else SecondarySlate
                                )
                            }
                        }
                    }
                }

                if (selectedType == "LOOKUP") {
                    var lookupQuery by remember { mutableStateOf("") }
                    val lookupResult by viewModel.lookupResult.collectAsState()
                    val lookupIsSearching by viewModel.lookupIsSearching.collectAsState()
                    val lookupStatusMessage by viewModel.lookupStatusMessage.collectAsState()

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Verify SEBI Credentials",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark
                            )
                            Text(
                                text = "Check if an Investment Adviser (RIA), Research Analyst (RA), Stock Broker, or Portfolio Manager is registered under SEBI guidelines.",
                                fontSize = 11.sp,
                                color = SecondarySlate,
                                lineHeight = 16.sp
                            )

                            OutlinedTextField(
                                value = lookupQuery,
                                onValueChange = { lookupQuery = it },
                                label = { Text("Advisor Name or SEBI Reg No.") },
                                placeholder = { Text("e.g. Sujith Research Analyst, INA100009876") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                trailingIcon = {
                                    if (lookupIsSearching) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = PrimaryAccent)
                                    } else {
                                        IconButton(
                                            onClick = { viewModel.lookupAdvisor(lookupQuery) },
                                            enabled = lookupQuery.trim().isNotEmpty()
                                        ) {
                                            Icon(Icons.Filled.Search, contentDescription = "Search", tint = PrimaryAccent)
                                        }
                                    }
                                },
                                singleLine = true
                            )

                            Button(
                                onClick = { viewModel.lookupAdvisor(lookupQuery) },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = lookupQuery.trim().isNotEmpty() && !lookupIsSearching,
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryAccent),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Search SEBI Registry", fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "TAP FOR QUICK VERIFICATION TESTING:",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )

                            val testCases = listOf(
                                "Aivo Sujith Wealth Advisory" to "Registered RIA",
                                "Elite Capital Wealth Advisors" to "Suspended RIA",
                                "Vintage Market Gurus" to "Expired RA",
                                "Lazard Asset Wealth" to "Clone Scam"
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                testCases.forEach { (name, label) ->
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                                            .border(0.5.dp, SlateBorder, RoundedCornerShape(12.dp))
                                            .clickable {
                                                lookupQuery = name
                                                viewModel.lookupAdvisor(name)
                                            }
                                            .padding(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                                            Text(label, fontSize = 9.sp, color = SecondarySlate)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Results section
                    if (lookupStatusMessage != null) {
                        Text(
                            text = lookupStatusMessage!!,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (lookupStatusMessage!!.contains("Found") || lookupStatusMessage!!.contains("Active")) RiskLow else if (lookupStatusMessage!!.contains("Searching") || lookupStatusMessage!!.contains("cache")) PrimaryAccent else RiskHigh,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            textAlign = TextAlign.Center
                        )
                    }

                    if (lookupResult != null) {
                        val advisor = lookupResult!!
                        val statusColor = when (advisor.status) {
                            "ACTIVE" -> RiskLow
                            "SUSPENDED" -> RiskMedium
                            "EXPIRED" -> Color.Gray
                            else -> RiskHigh
                        }
                        val statusBg = when (advisor.status) {
                            "ACTIVE" -> RiskLowLight
                            "SUSPENDED" -> RiskMediumLight
                            "EXPIRED" -> Color(0xFFF1F5F9)
                            else -> RiskHighLight
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceWhite)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(advisor.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PrimaryDark)
                                        Text("Reg No: ${advisor.registrationNumber}", fontSize = 11.sp, color = SecondarySlate)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(statusBg, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = advisor.status,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = statusColor
                                        )
                                    }
                                }

                                Divider(color = SlateBorder)

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Category, contentDescription = "Type", tint = PrimaryAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Category: ${advisor.type}", fontSize = 12.sp, color = PrimaryDark, fontWeight = FontWeight.Medium)
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Event, contentDescription = "Valid Until", tint = PrimaryAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Valid Until: ${advisor.validUntil}", fontSize = 12.sp, color = PrimaryDark, fontWeight = FontWeight.Medium)
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Mail, contentDescription = "Email", tint = PrimaryAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Email: ${advisor.contactEmail}", fontSize = 12.sp, color = PrimaryDark)
                                }

                                Row(verticalAlignment = Alignment.Top) {
                                    Icon(Icons.Filled.Place, contentDescription = "Address", tint = PrimaryAccent, modifier = Modifier.size(16.dp).padding(top = 2.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Address: ${advisor.address}", fontSize = 11.sp, color = Color.Gray, lineHeight = 16.sp)
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(statusBg.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("REGULATORY SCOPE & ADVISORY:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = statusColor)
                                        Text(advisor.advisoryScope, fontSize = 11.sp, color = PrimaryDark, lineHeight = 16.sp)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // 2. Main content forms based on type
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it },
                                label = { Text("Sender Name / Title") },
                                placeholder = { Text("e.g., WhatsApp: Stock Tips Group, Telegram Advisor") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            when (selectedType) {
                                "TEXT" -> {
                                    OutlinedTextField(
                                        value = contentText,
                                        onValueChange = { contentText = it },
                                        label = { Text("Pasted Message Content") },
                                        placeholder = { Text("Paste WhatsApp recommendation message, Telegram recommendation, SMS, or post text here...") },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                                "URL" -> {
                                    OutlinedTextField(
                                        value = urlText,
                                        onValueChange = { urlText = it },
                                        label = { Text("URL Link to Analyze") },
                                        placeholder = { Text("e.g., http://groww-shares-guaranteed.com") },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        leadingIcon = { Icon(Icons.Filled.Link, contentDescription = "Link") }
                                    )
                                }
                                "SCREENSHOT" -> {
                                    Text(
                                        text = "Upload Screenshot or Investment Flyer",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryDark
                                    )
                                    if (selectedBitmap != null) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(200.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(LightBg),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Image(
                                                bitmap = selectedBitmap!!.asImageBitmap(),
                                                contentDescription = "Selected Screenshot",
                                                modifier = Modifier.fillMaxSize()
                                            )
                                            IconButton(
                                                onClick = {
                                                    selectedBitmap = null
                                                    selectedImageUri = null
                                                },
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .padding(8.dp)
                                                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                            ) {
                                                Icon(Icons.Filled.Close, contentDescription = "Clear", tint = Color.White)
                                            }
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(140.dp)
                                                .background(LightBg, RoundedCornerShape(8.dp))
                                                .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                                                .clickable {
                                                    imagePickerLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(Icons.Filled.AddAPhoto, contentDescription = "Add image", tint = PrimaryAccent, modifier = Modifier.size(32.dp))
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text("Import screenshot from gallery", fontSize = 12.sp, color = SecondarySlate)
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = contentText,
                                        onValueChange = { contentText = it },
                                        label = { Text("Additional Context (Optional)") },
                                        placeholder = { Text("Add sender phone number, offer context, or notes...") },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                                "AUDIO" -> {
                                    Text(
                                        text = "Capture Voice Recommendation or Audio Call",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryDark
                                    )

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(LightBg, RoundedCornerShape(8.dp))
                                            .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            if (isRecording) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(56.dp)
                                                        .background(RiskHighLight, RoundedCornerShape(28.dp))
                                                        .clickable {
                                                            // Stop Recording
                                                            try {
                                                                mediaRecorder?.stop()
                                                                mediaRecorder?.release()
                                                                mediaRecorder = null
                                                                isRecording = false
                                                                Toast.makeText(context, "Voice advice recorded.", Toast.LENGTH_SHORT).show()
                                                            } catch (e: Exception) {
                                                                Log.e("InvestorShield", "Stop recording failed", e)
                                                            }
                                                        },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Filled.Stop, contentDescription = "Stop Recording", tint = RiskHigh, modifier = Modifier.size(24.dp))
                                                }
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text("RECORDING... Tap to stop", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RiskHigh)
                                                Text("Capturing speech patterns...", fontSize = 10.sp, color = Color.Gray)
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .size(56.dp)
                                                        .background(RiskLowLight, RoundedCornerShape(28.dp))
                                                        .clickable {
                                                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                        },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Filled.Mic, contentDescription = "Start Recording", tint = RiskLow, modifier = Modifier.size(24.dp))
                                                }
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text(
                                                    text = if (audioFile != null) "Recording saved! Tap to record again" else "Record Advice Clip",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = PrimaryDark
                                                )
                                                Text("Keep speaking to analyze voice tone, synthesis & content.", fontSize = 10.sp, color = Color.Gray)
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = contentText,
                                        onValueChange = { contentText = it },
                                        label = { Text("Context or Transcript notes (Optional)") },
                                        placeholder = { Text("e.g. Received a call claiming to be HDFC bank officer demanding immediate investments.") },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                            }
                        }
                    }

                    // 3. Advanced parameters
                    Text(
                        text = "Advanced Audit Capabilities",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = PrimaryDark
                    )

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Language, contentDescription = "Web Search", tint = PrimaryAccent, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Web Search Grounding", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                                    }
                                    Text("Uses live Google Search data to cross-reference registered advisors, regulatory alert lists, and verify domains on SEBI portal.", fontSize = 10.sp, color = SecondarySlate)
                                }
                                Switch(
                                    checked = useWebSearch,
                                    onCheckedChange = { useWebSearch = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PrimaryAccent)
                                )
                            }

                            Divider(color = SlateBorder)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Psychology, contentDescription = "Deep Thinking", tint = PrimaryAccent, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Forensic Reasoning Engine", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                                    }
                                    Text("Engages gemini-3.1-pro-preview with high reasoning budget to dissect high-level deceptive linguistics or clone screens.", fontSize = 10.sp, color = SecondarySlate)
                                }
                                Switch(
                                    checked = useDeepThinking,
                                    onCheckedChange = { useDeepThinking = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PrimaryAccent)
                                )
                            }
                        }
                    }

                    // 4. Action Button
                    Button(
                        onClick = {
                            val finalTitle = title.ifEmpty { "Unlabeled Scan ($selectedType)" }
                            val finalContent = when (selectedType) {
                                "URL" -> urlText
                                "SCREENSHOT" -> if (contentText.isEmpty()) "Screenshot uploaded" else contentText
                                "AUDIO" -> if (contentText.isEmpty()) "Audio recording saved" else contentText
                                else -> contentText
                            }

                            if (selectedType == "TEXT" && finalContent.trim().isEmpty()) {
                                Toast.makeText(context, "Please paste communication text to scan.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (selectedType == "URL" && urlText.trim().isEmpty()) {
                                Toast.makeText(context, "Please input a URL link to scan.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (selectedType == "SCREENSHOT" && selectedBitmap == null) {
                                Toast.makeText(context, "Please import a screenshot to scan.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            viewModel.startScan(
                                title = finalTitle,
                                contentType = selectedType,
                                content = finalContent,
                                bitmap = selectedBitmap,
                                useWebSearch = useWebSearch,
                                useDeepThinking = useDeepThinking
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryAccent)
                    ) {
                        Icon(Icons.Filled.Shield, contentDescription = "Scan icon")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Run Live Forensic Audit", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
        }
    }
}
}
