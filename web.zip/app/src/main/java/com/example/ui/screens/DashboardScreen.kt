package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.ScanEntity
import com.example.data.repository.SyncState
import com.example.ui.ScanViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: ScanViewModel,
    onNavigateToScan: () -> Unit,
    onNavigateToReport: (String) -> Unit,
    onNavigateToThreats: () -> Unit,
    onNavigateToChat: () -> Unit,
    onLogout: () -> Unit
) {
    val scans by viewModel.scans.collectAsState()
    val threats by viewModel.threats.collectAsState()
    val syncState by viewModel.syncState.collectAsState()

    val totalScans = scans.size
    val highRiskCount = scans.count { it.riskLevel == "HIGH" }
    val secureCount = scans.count { it.riskLevel == "LOW" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(PrimaryDark, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "Security Icon",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "InvestorShield",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = PrimaryDark,
                            letterSpacing = (-0.5).sp
                        )
                    }
                },
                actions = {
                    // Firebase Sync Status Button / Indicator
                    IconButton(onClick = { viewModel.syncDataWithFirebase() }) {
                        val icon = when (syncState) {
                            SyncState.SYNCING -> Icons.Filled.CloudSync
                            SyncState.SUCCESS -> Icons.Filled.CloudDone
                            SyncState.ERROR -> Icons.Filled.CloudOff
                            SyncState.IDLE -> Icons.Filled.CloudUpload
                        }
                        val tint = when (syncState) {
                            SyncState.SYNCING -> PrimaryAccent
                            SyncState.SUCCESS -> RiskLow
                            SyncState.ERROR -> RiskHigh
                            SyncState.IDLE -> SecondarySlate
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = "Sync state: $syncState",
                            tint = tint
                        )
                    }

                    IconButton(onClick = onNavigateToChat) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = "Compliance Chat",
                            tint = PrimaryAccent
                        )
                    }
                    val userName by viewModel.userProfileName.collectAsState()
                    val initials = userName.split(" ")
                        .mapNotNull { it.firstOrNull()?.toString() }
                        .take(2)
                        .joinToString("")
                        .uppercase()

                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(36.dp)
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(18.dp))
                            .border(1.dp, SlateBorder, RoundedCornerShape(18.dp))
                            .clickable { onLogout() }
                            .testTag("profile_logout_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initials.ifEmpty { "JD" },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceWhite,
                    scrolledContainerColor = SurfaceWhite
                ),
                modifier = Modifier.border(width = (0.5).dp, color = SlateBorder)
            )
        },
        containerColor = LightBg
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Clean Utility / Minimal Hero Scan Trigger Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                        .background(
                            color = PrimaryAccent.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(24.dp)
                        )
                        .border(1.dp, PrimaryAccent.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToScan() },
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = PrimaryDark)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "SECURITY PROTOCOL",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8),
                                    letterSpacing = 1.5.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Run AI Analysis",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    letterSpacing = (-0.5).sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Verify media, docs, or links",
                                    fontSize = 13.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(26.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AddAPhoto,
                                    contentDescription = "Scan Icon",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Metrics overview row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricCard(
                        title = "Secured Scans",
                        value = secureCount.toString(),
                        subtitle = "Clean verification",
                        icon = Icons.Outlined.CheckCircle,
                        tint = RiskLow,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Threats Blocked",
                        value = highRiskCount.toString(),
                        subtitle = "High risk scams",
                        icon = Icons.Outlined.ErrorOutline,
                        tint = RiskHigh,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 3. Quick actions navigation shortcuts
            item {
                Text(
                    text = "Shield Verification Methods",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = PrimaryDark,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickActionItem(
                        title = "Text Audit",
                        subtitle = "WhatsApp & SMS",
                        icon = Icons.Outlined.ContentPaste,
                        onClick = onNavigateToScan,
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionItem(
                        title = "Reputation",
                        subtitle = "Phishing URLs",
                        icon = Icons.Outlined.Language,
                        onClick = onNavigateToScan,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickActionItem(
                        title = "Screenshots",
                        subtitle = "Image forensic",
                        icon = Icons.Outlined.Screenshot,
                        onClick = onNavigateToScan,
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionItem(
                        title = "Voice Clone",
                        subtitle = "Audio Deepfake",
                        icon = Icons.Outlined.Mic,
                        onClick = onNavigateToScan,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToScan() }
                        .border(1.dp, PrimaryAccent.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = PrimaryLight.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(PrimaryAccent.copy(alpha = 0.2f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = "SEBI Lookup",
                                tint = PrimaryAccent,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SEBI Registry Credentials Lookup",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = PrimaryDark
                            )
                            Text(
                                text = "Verify registration codes & active licenses of investment advisers.",
                                fontSize = 11.sp,
                                color = SecondarySlate
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.ChevronRight,
                            contentDescription = "Navigate",
                            tint = PrimaryAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // 4. Live Threat Intel section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Active SEBI Warnings & Threat Feed",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = PrimaryDark
                    )
                    Text(
                        text = "Manage DB",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = PrimaryAccent,
                        modifier = Modifier
                            .clickable { onNavigateToThreats() }
                            .padding(4.dp)
                    )
                }
            }

            if (threats.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceWhite, RoundedCornerShape(8.dp))
                            .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No recorded threat indicators in database.",
                            fontSize = 13.sp,
                            color = SecondarySlate
                        )
                    }
                }
            } else {
                items(threats.take(3)) { threat ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SlateBorder, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        if (threat.severity == "HIGH") RiskHighLight else RiskMediumLight,
                                        RoundedCornerShape(6.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (threat.severity == "HIGH") Icons.Filled.Warning else Icons.Filled.Info,
                                    contentDescription = "Threat Icon",
                                    tint = if (threat.severity == "HIGH") RiskHigh else RiskMedium,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = threat.entityName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = PrimaryDark,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (threat.severity == "HIGH") RiskHighLight else RiskMediumLight,
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = threat.severity,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (threat.severity == "HIGH") RiskHigh else RiskMedium
                                        )
                                    }
                                }
                                Text(
                                    text = "Type: ${threat.type} | Indicator: ${threat.indicator}",
                                    fontSize = 11.sp,
                                    color = SecondarySlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = threat.notes,
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // 5. Recent forensic scans history
            item {
                Text(
                    text = "Recent Forensic Audits",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = PrimaryDark,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (scans.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceWhite, RoundedCornerShape(8.dp))
                            .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ContentPasteSearch,
                            contentDescription = "Empty History",
                            tint = Color.LightGray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No recent scans conducted",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PrimaryDark
                        )
                        Text(
                            text = "Your scanned links, SMS advice, and audio files will appear here.",
                            fontSize = 12.sp,
                            color = SecondarySlate,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                items(scans) { scan ->
                    ScanHistoryItem(
                        scan = scan,
                        onClick = { onNavigateToReport(scan.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = tint,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryDark,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = title.uppercase(Locale.getDefault()),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = SecondarySlate,
                letterSpacing = 0.5.sp
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(SurfaceWhite, RoundedCornerShape(16.dp))
            .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(Color(0xFFEEF2F6), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = PrimaryAccent,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryDark
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = SecondarySlate
            )
        }
    }
}

@Composable
fun ScanHistoryItem(
    scan: ScanEntity,
    onClick: () -> Unit
) {
    val dateString = remember(scan.timestamp) {
        val formatter = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        formatter.format(Date(scan.timestamp))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F4F7))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(SurfaceWhite, RoundedCornerShape(12.dp))
                    .border(0.5.dp, SlateBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (scan.contentType) {
                        "TEXT" -> Icons.Outlined.Description
                        "URL" -> Icons.Outlined.Language
                        "SCREENSHOT" -> Icons.Outlined.Image
                        "AUDIO" -> Icons.Outlined.VolumeUp
                        else -> Icons.Outlined.Shield
                    },
                    contentDescription = "Content Type Icon",
                    tint = SecondarySlate,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = scan.title.ifEmpty { "Untitled Scan" },
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = PrimaryDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Box(
                        modifier = Modifier
                            .background(
                                when (scan.riskLevel) {
                                    "LOW" -> Color(0xFFD1FAE5) // emerald-100
                                    "MEDIUM" -> Color(0xFFFEF3C7) // amber-100
                                    else -> Color(0xFFFFE4E6) // rose-100
                                },
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (scan.riskLevel == "LOW") "VERIFIED" else if (scan.riskLevel == "MEDIUM") "SUSPICIOUS" else "HIGH RISK",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (scan.riskLevel) {
                                "LOW" -> RiskLow
                                "MEDIUM" -> RiskMedium
                                else -> RiskHigh
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$dateString • Score: ${scan.riskScore}%",
                    fontSize = 12.sp,
                    color = SecondarySlate
                )
            }
        }
    }
}
