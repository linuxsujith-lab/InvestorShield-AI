package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.api.SebiNewsItem
import com.example.ui.ChatMessage
import com.example.ui.ScanViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SebiNewsScreen(
    viewModel: ScanViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val newsList by viewModel.sebiNews.collectAsState()
    val isFetching by viewModel.isFetchingNews.collectAsState()
    val selectedNews by viewModel.selectedNewsItem.collectAsState()
    val chatMessages by viewModel.newsChatMessages.collectAsState()
    val isSendingMsg by viewModel.isSendingNewsChatMessage.collectAsState()

    var activeMobileTab by remember { mutableStateOf(0) } // 0: News, 1: AI Chatbot
    var chatInput by remember { mutableStateOf("") }
    val chatListState = rememberLazyListState()

    // Auto scroll chat to bottom
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            chatListState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(RiskLowLight, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Newspaper,
                                contentDescription = "News",
                                tint = RiskLow,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "SEBI Compliance News",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = PrimaryDark,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "Daily AI Regulatory Intelligence",
                                fontSize = 10.sp,
                                color = SecondarySlate
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("news_back_button")) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = PrimaryDark)
                    }
                },
                actions = {
                    if (isFetching) {
                        CircularProgressIndicator(
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .size(20.dp),
                            strokeWidth = 2.dp,
                            color = PrimaryAccent
                        )
                    } else {
                        IconButton(
                            onClick = {
                                viewModel.fetchSebiNewsFromAI()
                                Toast.makeText(context, "Fetching fresh daily regulatory news...", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("news_refresh_button")
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = "Fetch AI News", tint = PrimaryAccent)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceWhite,
                    scrolledContainerColor = SurfaceWhite
                ),
                modifier = Modifier.border(width = 0.5.dp, color = SlateBorder)
            )
        },
        containerColor = LightBg
    ) { paddingValues ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            val isWideScreen = maxWidth >= 650.dp

            if (isWideScreen) {
                // Wide Screen Layout: Left side news list, Right side details & Chatbot
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Left Column (60%): News Feed List & Active Detail
                    Column(
                        modifier = Modifier
                            .weight(0.58f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Daily Circulars & Alerts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PrimaryLight,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                        
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(newsList) { item ->
                                NewsCard(
                                    item = item,
                                    isSelected = selectedNews == item,
                                    onClick = { viewModel.selectNewsItem(item) }
                                )
                            }
                        }

                        // Selected News Detail viewer at the bottom of the news section
                        selectedNews?.let { news ->
                            NewsDetailsSection(news = news)
                        }
                    }

                    // Divider Line
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(1.dp)
                            .background(SlateBorder)
                    )

                    // Right Column (42%): SEBI Assistant News Chatbot
                    Column(
                        modifier = Modifier
                            .weight(0.42f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceWhite)
                            .border(width = 0.5.dp, color = SlateBorder, shape = RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        NewsChatbotHeader(
                            selectedNewsTitle = selectedNews?.title ?: "SEBI Directives",
                            onClearChat = { viewModel.clearNewsChat() }
                        )

                        // Chat messages box
                        Box(modifier = Modifier.weight(1f)) {
                            NewsChatMessagesList(
                                chatMessages = chatMessages,
                                isSendingMsg = isSendingMsg,
                                listState = chatListState
                            )
                        }

                        // Input field
                        NewsChatInputField(
                            value = chatInput,
                            onValueChange = { chatInput = it },
                            onSend = {
                                viewModel.sendNewsChatMessage(chatInput)
                                chatInput = ""
                            },
                            isSending = isSendingMsg
                        )
                    }
                }
            } else {
                // Mobile Layout: Tabbed interface to switch between News stream and AI Analyst
                Column(modifier = Modifier.fillMaxSize()) {
                    TabRow(
                        selectedTabIndex = activeMobileTab,
                        containerColor = SurfaceWhite,
                        contentColor = PrimaryDark,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[activeMobileTab]),
                                color = PrimaryAccent
                            )
                        },
                        modifier = Modifier.border(width = 0.5.dp, color = SlateBorder)
                    ) {
                        Tab(
                            selected = activeMobileTab == 0,
                            onClick = { activeMobileTab = 0 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.ListAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("News Feed", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                            },
                            modifier = Modifier.testTag("news_feed_tab")
                        )
                        Tab(
                            selected = activeMobileTab == 1,
                            onClick = { activeMobileTab = 1 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.SupportAgent, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("AI Analyst", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                            },
                            modifier = Modifier.testTag("news_analyst_tab")
                        )
                    }

                    if (activeMobileTab == 0) {
                        // Mobile News Tab
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            LazyColumn(
                                modifier = Modifier.weight(1.3f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(newsList) { item ->
                                    NewsCard(
                                        item = item,
                                        isSelected = selectedNews == item,
                                        onClick = { viewModel.selectNewsItem(item) }
                                    )
                                }
                            }

                            selectedNews?.let { news ->
                                NewsDetailsSection(
                                    news = news,
                                    modifier = Modifier.weight(1f),
                                    onAskAnalyst = {
                                        activeMobileTab = 1
                                    }
                                )
                            }
                        }
                    } else {
                        // Mobile Chatbot Tab
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(SurfaceWhite)
                                .padding(12.dp)
                        ) {
                            NewsChatbotHeader(
                                selectedNewsTitle = selectedNews?.title ?: "SEBI Directives",
                                onClearChat = { viewModel.clearNewsChat() }
                            )

                            // Chat messages list
                            Box(modifier = Modifier.weight(1f)) {
                                NewsChatMessagesList(
                                    chatMessages = chatMessages,
                                    isSendingMsg = isSendingMsg,
                                    listState = chatListState
                                )
                            }

                            // Input field
                            NewsChatInputField(
                                value = chatInput,
                                onValueChange = { chatInput = it },
                                onSend = {
                                    viewModel.sendNewsChatMessage(chatInput)
                                    chatInput = ""
                                },
                                isSending = isSendingMsg
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewsCard(
    item: SebiNewsItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val severityColor = when (item.severity.uppercase()) {
        "HIGH" -> RiskHigh
        "MEDIUM" -> RiskMedium
        else -> RiskLow
    }

    val severityBg = when (item.severity.uppercase()) {
        "HIGH" -> RiskHighLight
        "MEDIUM" -> RiskMediumLight
        else -> RiskLowLight
    }

    val categoryColor = when (item.category.uppercase()) {
        "WARNING" -> RiskHigh
        "CIRCULAR" -> PrimaryAccent
        "ADVISORY" -> Color(0xFF6366F1) // Indigo
        else -> SecondarySlate
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = if (isSelected) PrimaryAccent else SlateBorder,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .testTag("news_card_${item.title.take(10).replace(" ", "_")}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SurfaceWhite else SurfaceWhite.copy(alpha = 0.8f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 2.dp else 0.dp
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Chip
                Box(
                    modifier = Modifier
                        .background(categoryColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.category.uppercase(),
                        color = categoryColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Severity Chip
                    Box(
                        modifier = Modifier
                            .background(severityBg, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.severity.uppercase(),
                            color = severityColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.date,
                        color = SecondarySlate,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = PrimaryDark,
                lineHeight = 17.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = item.content,
                fontSize = 11.sp,
                color = SecondarySlate,
                lineHeight = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun NewsDetailsSection(
    news: SebiNewsItem,
    modifier: Modifier = Modifier,
    onAskAnalyst: (() -> Unit)? = null
) {
    val severityColor = when (news.severity.uppercase()) {
        "HIGH" -> RiskHigh
        "MEDIUM" -> RiskMedium
        else -> RiskLow
    }

    val severityBg = when (news.severity.uppercase()) {
        "HIGH" -> RiskHighLight
        "MEDIUM" -> RiskMediumLight
        else -> RiskLowLight
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceWhite)
            .border(width = 0.5.dp, color = SlateBorder, shape = RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "READER PANEL",
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = SecondarySlate,
                letterSpacing = 1.sp
            )
            Box(
                modifier = Modifier
                    .background(severityBg, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "SEVERITY: ${news.severity.uppercase()}",
                    color = severityColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            text = news.title,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = PrimaryDark,
            lineHeight = 19.sp
        )

        Divider(color = SlateBorder, thickness = 0.5.dp)

        Text(
            text = news.content,
            fontSize = 12.sp,
            color = PrimaryLight,
            lineHeight = 17.sp
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Actions/Impact Block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(RiskLowLight.copy(alpha = 0.4f))
                .border(width = 0.5.dp, color = RiskLow.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp))
                .padding(8.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = RiskLow,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "RETAIL INVESTOR IMPACT",
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        color = RiskLow
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = news.impact,
                    fontSize = 11.sp,
                    color = PrimaryLight,
                    lineHeight = 15.sp
                )
            }
        }

        if (onAskAnalyst != null) {
            Button(
                onClick = onAskAnalyst,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .testTag("news_ask_analyst_button"),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryAccent),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Discuss with SEBI AI Assistant", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun NewsChatbotHeader(
    selectedNewsTitle: String,
    onClearChat: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.SupportAgent,
                    contentDescription = null,
                    tint = PrimaryAccent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "AI News Assistant",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = PrimaryDark
                )
            }
            Text(
                text = "Context: ${selectedNewsTitle.take(30)}...",
                fontSize = 10.sp,
                color = SecondarySlate,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(
            onClick = onClearChat,
            modifier = Modifier.size(24.dp).testTag("news_chat_clear")
        ) {
            Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear Chat", tint = Color.Gray, modifier = Modifier.size(18.dp))
        }
    }
    Divider(color = SlateBorder, thickness = 0.5.dp)
}

@Composable
fun NewsChatMessagesList(
    chatMessages: List<ChatMessage>,
    isSendingMsg: Boolean,
    listState: androidx.compose.foundation.lazy.LazyListState = rememberLazyListState()
) {
    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(chatMessages) { message ->
            val isUser = message.sender == "USER"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
            ) {
                Box(
                    modifier = Modifier
                        .widthIn(max = 240.dp)
                        .clip(
                            RoundedCornerShape(
                                topStart = 10.dp,
                                topEnd = 10.dp,
                                bottomStart = if (isUser) 10.dp else 0.dp,
                                bottomEnd = if (isUser) 0.dp else 10.dp
                            )
                        )
                        .background(if (isUser) PrimaryAccent else SlateBorder.copy(alpha = 0.5f))
                        .padding(10.dp)
                ) {
                    Text(
                        text = message.text,
                        color = if (isUser) Color.White else PrimaryDark,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        if (isSendingMsg) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(SlateBorder.copy(alpha = 0.3f))
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                strokeWidth = 1.5.dp,
                                color = SecondarySlate
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Analyst is writing...",
                                color = SecondarySlate,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewsChatInputField(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    isSending: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text("Ask about this regulation...", fontSize = 12.sp) },
            modifier = Modifier
                .weight(1f)
                .testTag("news_chat_input"),
            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryAccent,
                unfocusedBorderColor = SlateBorder,
                focusedContainerColor = LightBg,
                unfocusedContainerColor = LightBg
            ),
            shape = RoundedCornerShape(8.dp)
        )
        IconButton(
            onClick = onSend,
            enabled = value.trim().isNotEmpty() && !isSending,
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (value.trim().isNotEmpty() && !isSending) PrimaryAccent else SlateBorder)
                .testTag("news_chat_send_button")
        ) {
            Icon(
                imageVector = Icons.Filled.Send,
                contentDescription = "Send",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
