package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.ScanEntity
import com.example.data.database.ThreatIntelligenceEntity
import com.example.data.database.SebiAdvisorEntity
import com.example.data.repository.ScanRepository
import com.example.data.api.Content
import com.example.data.api.Part
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GeminiApiService
import com.example.data.api.NvidiaApiService
import com.example.data.api.NvidiaMessage
import com.example.data.api.NvidiaChatRequest
import com.example.data.api.SebiNewsItem
import org.json.JSONArray
import org.json.JSONObject
import com.example.BuildConfig
import com.example.data.repository.FirebaseSyncManager
import com.example.data.repository.SyncState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // USER or GEMINI
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class ScanViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = ScanRepository(db.scanDao(), db.threatIntelligenceDao(), db.sebiAdvisorDao())

    val scans: StateFlow<List<ScanEntity>> = repository.allScans
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val threats: StateFlow<List<ThreatIntelligenceEntity>> = repository.allThreats
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val firebaseSyncManager = FirebaseSyncManager.getInstance()
    val syncState: StateFlow<SyncState> = firebaseSyncManager.syncState
    val lastSyncTime: StateFlow<Long> = firebaseSyncManager.lastSyncTime

    // User Profile State
    private val _userUid = MutableStateFlow("sujith_uid")
    val userUid: StateFlow<String> = _userUid

    private val _userProfileName = MutableStateFlow("Aivo Sujith")
    val userProfileName: StateFlow<String> = _userProfileName

    private val _userProfileEmail = MutableStateFlow("aivosujith@gmail.com")
    val userProfileEmail: StateFlow<String> = _userProfileEmail

    private val _userProfileRole = MutableStateFlow("Executive Account")
    val userProfileRole: StateFlow<String> = _userProfileRole

    private val _userProfileBio = MutableStateFlow("Enterprise security researcher and retail investor protecting financial portfolios from bad actors.")
    val userProfileBio: StateFlow<String> = _userProfileBio

    private val _totalScans = MutableStateFlow(124)
    val totalScans: StateFlow<Int> = _totalScans

    private val _criticalThreats = MutableStateFlow(8)
    val criticalThreats: StateFlow<Int> = _criticalThreats

    private val _riskProtectionScore = MutableStateFlow(94)
    val riskProtectionScore: StateFlow<Int> = _riskProtectionScore

    private val _biometricEnabled = MutableStateFlow(false)
    val biometricEnabled: StateFlow<Boolean> = _biometricEnabled

    init {
        fetchProfileFromFirestore("sujith_uid")
    }

    fun setBiometricEnabled(enabled: Boolean) {
        _biometricEnabled.value = enabled
    }

    fun setLoggedInUser(email: String, name: String) {
        _userProfileEmail.value = email
        _userProfileName.value = name
        val cleanEmail = email.trim().lowercase()
        val uid = if (cleanEmail == "aivosujith@gmail.com") "sujith_uid" 
                  else if (cleanEmail == "guest.investor@gmail.com") "guest_uid"
                  else "user_" + cleanEmail.hashCode().coerceAtLeast(0)
        _userUid.value = uid
        
        fetchProfileFromFirestore(uid)
    }

    fun fetchProfileFromFirestore(uid: String) {
        viewModelScope.launch {
            val loaded = firebaseSyncManager.fetchUserProfile(uid)
            if (loaded != null) {
                _userProfileName.value = loaded.name
                _userProfileEmail.value = loaded.email
                _userProfileRole.value = loaded.role
                _userProfileBio.value = loaded.bio
                _totalScans.value = loaded.totalScans
                _criticalThreats.value = loaded.criticalThreats
                _riskProtectionScore.value = loaded.riskProtectionScore
            } else {
                if (uid == "guest_uid") {
                    _userProfileName.value = "Guest Investor"
                    _userProfileRole.value = "Retail Advisor"
                    _totalScans.value = 45
                    _criticalThreats.value = 2
                    _riskProtectionScore.value = 81
                } else if (uid == "sujith_uid") {
                    _userProfileName.value = "Aivo Sujith"
                    _userProfileRole.value = "Executive Account"
                    _totalScans.value = 124
                    _criticalThreats.value = 8
                    _riskProtectionScore.value = 94
                }
            }
        }
    }

    fun updateProfile(name: String, role: String, bio: String) {
        _userProfileName.value = name
        _userProfileRole.value = role
        _userProfileBio.value = bio
        
        viewModelScope.launch {
            val profile = com.example.data.repository.UserProfile(
                uid = _userUid.value,
                name = name,
                email = _userProfileEmail.value,
                role = role,
                bio = bio,
                totalScans = _totalScans.value,
                criticalThreats = _criticalThreats.value,
                riskProtectionScore = _riskProtectionScore.value
            )
            firebaseSyncManager.saveUserProfile(profile)
        }
    }

    fun syncDataWithFirebase() {
        viewModelScope.launch {
            firebaseSyncManager.syncData(scans.value, threats.value)
        }
    }

    // SEBI Registered Advisor Lookup States & Actions
    val allAdvisors: StateFlow<List<SebiAdvisorEntity>> = repository.allAdvisors
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _lookupResult = MutableStateFlow<SebiAdvisorEntity?>(null)
    val lookupResult: StateFlow<SebiAdvisorEntity?> = _lookupResult

    private val _lookupIsSearching = MutableStateFlow(false)
    val lookupIsSearching: StateFlow<Boolean> = _lookupIsSearching

    private val _lookupStatusMessage = MutableStateFlow<String?>(null)
    val lookupStatusMessage: StateFlow<String?> = _lookupStatusMessage

    fun clearLookupState() {
        _lookupResult.value = null
        _lookupIsSearching.value = false
        _lookupStatusMessage.value = null
    }

    fun lookupAdvisor(query: String) {
        if (query.trim().isEmpty()) return
        
        _lookupIsSearching.value = true
        _lookupStatusMessage.value = "Searching official database..."
        _lookupResult.value = null

        viewModelScope.launch {
            try {
                // 1. Check local Room database first
                val localAdvisor = repository.lookupAdvisor(query.trim())
                if (localAdvisor != null) {
                    _lookupResult.value = localAdvisor
                    _lookupStatusMessage.value = "Found match in SEBI Registry!"
                    _lookupIsSearching.value = false
                    return@launch
                }

                // 2. Fall back to live LLM verification if not in local db
                _lookupStatusMessage.value = "Not found in local cache. Invoking live SEBI compliance verify..."
                
                val apiService = NvidiaApiService.create()
                val systemInstruction = """
                    You are InvestorShield's SEBI Advisor Verification Agent.
                    The user is looking up an investment adviser, research analyst, broker, or portfolio manager by name or registration number: "$query"
                    
                    Verify this advisor and respond ONLY with a raw JSON object containing these exact fields:
                    - "registrationNumber": String (matching or simulated registered SEBI code starting with INA, INH, INP or INZ. If completely unregulated/scam, write "UNREGISTERED")
                    - "name": String (the full official name)
                    - "type": String (e.g., "Investment Adviser (RIA)", "Research Analyst (RA)", "Stock Broker (SB)", "Portfolio Manager (PMS)", or "UNREGISTERED")
                    - "status": String ("ACTIVE", "SUSPENDED", "EXPIRED", or "UNREGISTERED")
                    - "validUntil": String (e.g. "2029-12-31" or "PERPETUAL" or "N/A")
                    - "address": String (the physical address of their headquarters or "Unknown")
                    - "contactEmail": String (their official compliance or support email or "Unknown")
                    - "advisoryScope": String (1-2 sentences on what they are authorized to do under SEBI guidelines, or warning details if unregistered/scam)
                    
                    Rules:
                    1. If the input resembles a known entity but has minor spelling differences, correct it and return ACTIVE.
                    2. If the input is a known scam or telegram stock tip group, return status "UNREGISTERED" and details of the threat.
                    3. Return ONLY valid JSON, do not wrap in markdown ```json.
                """.trimIndent()

                val responseText = try {
                    val authHeader = "Bearer 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"
                    val response = apiService.chatCompletions(
                        authorization = authHeader,
                        request = NvidiaChatRequest(
                            model = "meta/llama-3.1-405b-instruct",
                            messages = listOf(
                                NvidiaMessage(role = "system", content = systemInstruction),
                                NvidiaMessage(role = "user", content = "Verify registration of: $query")
                            )
                        )
                    )
                    response.choices?.firstOrNull()?.message?.content ?: ""
                } catch (e: Exception) {
                    Log.e("ScanViewModel", "Nvidia API failed for advisor lookup, using local default", e)
                    ""
                }

                if (responseText.isNotEmpty()) {
                    try {
                        val cleanedJson = responseText.trim()
                            .removePrefix("```json")
                            .removePrefix("```")
                            .removeSuffix("```")
                            .trim()
                        
                        val json = JSONObject(cleanedJson)
                        val advisor = SebiAdvisorEntity(
                            registrationNumber = json.optString("registrationNumber", "UNREGISTERED"),
                            name = json.optString("name", query),
                            type = json.optString("type", "UNREGISTERED"),
                            status = json.optString("status", "UNREGISTERED"),
                            validUntil = json.optString("validUntil", "N/A"),
                            address = json.optString("address", "Unknown"),
                            contactEmail = json.optString("contactEmail", "Unknown"),
                            advisoryScope = json.optString("advisoryScope", "Unregistered entity. High financial risk. Avoid stock tip channels.")
                        )
                        _lookupResult.value = advisor
                        _lookupStatusMessage.value = if (advisor.status == "ACTIVE") "Active Registered Entity Found!" else "Entity is Unregistered or Non-Compliant!"
                    } catch (e: Exception) {
                        Log.e("ScanViewModel", "Failed to parse simulated API response", e)
                        _lookupStatusMessage.value = "Registry lookup failed. Treated as Unregistered."
                    }
                } else {
                    _lookupStatusMessage.value = "No response from live registry. Treated as Unregistered."
                }
            } catch (e: Exception) {
                Log.e("ScanViewModel", "Error looking up advisor", e)
                _lookupStatusMessage.value = "Error connecting to registry services: ${e.localizedMessage}"
            } finally {
                _lookupIsSearching.value = false
            }
        }
    }

    init {
        viewModelScope.launch {
            kotlinx.coroutines.delay(1500)
            syncDataWithFirebase()
        }
    }

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val _scanResult = MutableStateFlow<ScanEntity?>(null)
    val scanResult: StateFlow<ScanEntity?> = _scanResult

    private val _scanningStatus = MutableStateFlow("")
    val scanningStatus: StateFlow<String> = _scanningStatus

    // Chat States
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage(
            sender = "GEMINI",
            text = "Welcome to InvestorShield Compliance Advisor. I can help verify investment offers, explain SEBI regulations, or advise you on how to spot fraudulent stock advisors. What can I check for you today?"
        )
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    private val _isSendingMessage = MutableStateFlow(false)
    val isSendingMessage: StateFlow<Boolean> = _isSendingMessage

    // Trigger dynamic forensic scanning
    fun startScan(
        title: String,
        contentType: String,
        content: String,
        bitmap: Bitmap? = null,
        useWebSearch: Boolean,
        useDeepThinking: Boolean
    ) {
        viewModelScope.launch {
            _isScanning.value = true
            _scanResult.value = null
            
            _scanningStatus.value = "Initializing threat crosscheck..."
            kotlinx.coroutines.delay(400)
            
            _scanningStatus.value = "Consulting offline SEBI registry indicators..."
            kotlinx.coroutines.delay(500)
            
            _scanningStatus.value = if (useDeepThinking) {
                "Assembling reasoning engine with gemini-3.1-pro-preview..."
            } else {
                "Spinning up audit engine with gemini-3.5-flash..."
            }
            kotlinx.coroutines.delay(600)
            
            _scanningStatus.value = if (useWebSearch) {
                "Querying live SEBI lists and financial reputation sources..."
            } else {
                "Performing linguistic forensic scan..."
            }
            
            try {
                val result = repository.scanContent(
                    title = title,
                    contentType = contentType,
                    content = content,
                    bitmap = bitmap,
                    useWebSearch = useWebSearch,
                    useDeepThinking = useDeepThinking
                )
                _scanResult.value = result
                syncDataWithFirebase()
            } catch (e: Exception) {
                Log.e("InvestorShield", "Scanning flow crashed", e)
            } finally {
                _isScanning.value = false
                _scanningStatus.value = ""
            }
        }
    }

    fun clearScanResult() {
        _scanResult.value = null
    }

    fun deleteScan(id: String) {
        viewModelScope.launch {
            repository.deleteScanById(id)
            syncDataWithFirebase()
        }
    }

    fun clearAllScans() {
        viewModelScope.launch {
            repository.deleteAllScans()
            syncDataWithFirebase()
        }
    }

    // Threat intelligence management
    fun addThreatIntel(
        name: String,
        type: String,
        indicator: String,
        severity: String,
        notes: String
    ) {
        viewModelScope.launch {
            val threat = ThreatIntelligenceEntity(
                entityName = name,
                type = type,
                indicator = indicator,
                severity = severity,
                notes = notes
            )
            repository.insertThreat(threat)
            syncDataWithFirebase()
        }
    }

    fun deleteThreatIntel(id: String) {
        viewModelScope.launch {
            repository.deleteThreatById(id)
            syncDataWithFirebase()
        }
    }

    // NVIDIA Advisor Chatbot Integration
    fun sendChatMessage(text: String) {
        if (text.trim().isEmpty()) return
        
        val userMsg = ChatMessage(sender = "USER", text = text)
        _chatMessages.value = _chatMessages.value + userMsg
        _isSendingMessage.value = true

        viewModelScope.launch {
            val apiService = NvidiaApiService.create()

            val systemInstruction = """
                You are InvestorShield's Expert AI Compliance Chatbot, specialized in India's financial securities regulatory landscape.
                Your task is to advise retail investors, identify red flags in mutual funds, stock advice, PMS, and IPO subscriptions, and cite SEBI regulations where appropriate.
                Always be objective, clear, and professional. 
                Remind the user never to invest in unregistered advisory services and to always verify registration on the SEBI portal.
            """.trimIndent()

            val nvidiaMessages = mutableListOf<NvidiaMessage>()
            nvidiaMessages.add(NvidiaMessage(role = "system", content = systemInstruction))
            
            var expectedRole = "user"
            _chatMessages.value.takeLast(10).forEach { msg ->
                val role = if (msg.sender == "USER") "user" else "assistant"
                if (role == expectedRole) {
                    nvidiaMessages.add(NvidiaMessage(role = role, content = msg.text))
                    expectedRole = if (role == "user") "assistant" else "user"
                }
            }

            val request = NvidiaChatRequest(
                model = "google/gemma-3n-e2b-it",
                messages = nvidiaMessages,
                max_tokens = 1024,
                temperature = 0.20f,
                top_p = 0.70f,
                frequency_penalty = 0.00f,
                presence_penalty = 0.00f,
                stream = false
            )

            try {
                val authHeader = "Bearer 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"
                val response = apiService.chatCompletions(authHeader, request = request)
                val replyText = response.choices?.firstOrNull()?.message?.content
                    ?: "I'm having trouble retrieving details. Please ensure you are connected to the internet and check your API keys."
                
                _chatMessages.value = _chatMessages.value + ChatMessage(sender = "GEMINI", text = replyText)
            } catch (e: Exception) {
                Log.e("InvestorShieldChat", "Chat API failed", e)
                _chatMessages.value = _chatMessages.value + ChatMessage(
                    sender = "GEMINI",
                    text = "A connection error occurred. I could not reach the InvestorShield server. Please verify your internet connection. (Error: ${e.localizedMessage})"
                )
            } finally {
                _isSendingMessage.value = false
            }
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = "GEMINI",
                text = "Chat history cleared. How else can I assist you with SEBI compliance or scam detection?"
            )
        )
    }

    // --- SEBI Related News States ---
    private val defaultNews = listOf(
        SebiNewsItem(
            title = "SEBI Warning on Social Media 'Finfluencers' Promising Guaranteed Returns",
            category = "Warning",
            date = "July 2, 2026",
            content = "SEBI has cautioned retail investors against unregistered stock tip channels operating on Telegram and WhatsApp. The regulator noted a surge in unregulated advisors charging high subscription fees and offering fake, guaranteed double-your-money schemes.",
            impact = "Avoid buying tips from unregistered entities and always check the SEBI website for registered investment advisors (RIA) before committing capital.",
            severity = "High"
        ),
        SebiNewsItem(
            title = "New Guidelines for ASBA-like Facility for Secondary Market Trading",
            category = "Circular",
            date = "July 1, 2026",
            content = "SEBI has introduced a voluntary Application Supported by Blocked Amount (ASBA) style blocking of funds for secondary market trading. This mechanism protects investor funds by blocking money in their bank accounts instead of transferring it to stockbrokers.",
            impact = "Opt into the fund-blocking mechanism with your demat/trading broker to safeguard your capital against broker defaults.",
            severity = "Low"
        ),
        SebiNewsItem(
            title = "SEBI Action Against Shell Portfolio Management Services (PMS)",
            category = "Press Release",
            date = "June 28, 2026",
            content = "Following a forensic audit, SEBI has suspended registrations of three Portfolio Management Services for diverting retail client funds into illiquid penny stocks. Demat accounts of the operating promoters have been frozen.",
            impact = "Verify the historical performance audits and compliance records of any PMS provider via SEBI's official disclosure database.",
            severity = "Medium"
        ),
        SebiNewsItem(
            title = "Advisory on Fake Demat Account Creation Scams",
            category = "Advisory",
            date = "June 25, 2026",
            content = "The regulator issued an urgent advisory warning against identity theft where scammers open unauthorized demat accounts using stolen Aadhaar and PAN cards. Investors are advised to regularly monitor their NSDL/CDSL consolidated statements.",
            impact = "Check your consolidated account statement (CAS) monthly and report any unrecognized demat accounts or transactions immediately to SEBI SCORES.",
            severity = "High"
        )
    )

    private val _sebiNews = MutableStateFlow<List<SebiNewsItem>>(defaultNews)
    val sebiNews: StateFlow<List<SebiNewsItem>> = _sebiNews

    private val _isFetchingNews = MutableStateFlow(false)
    val isFetchingNews: StateFlow<Boolean> = _isFetchingNews

    private val _selectedNewsItem = MutableStateFlow<SebiNewsItem?>(defaultNews.firstOrNull())
    val selectedNewsItem: StateFlow<SebiNewsItem?> = _selectedNewsItem

    fun selectNewsItem(item: SebiNewsItem) {
        _selectedNewsItem.value = item
    }

    // Small Chatbot for News section
    private val _newsChatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage(
            sender = "GEMINI",
            text = "Hello! I am your SEBI News Analyst. Click on any news article on the left, and I can explain its regulatory details, clarify its impact on your portfolio, or answer any compliance questions. How can I help you today?"
        )
    ))
    val newsChatMessages: StateFlow<List<ChatMessage>> = _newsChatMessages

    private val _isSendingNewsChatMessage = MutableStateFlow(false)
    val isSendingNewsChatMessage: StateFlow<Boolean> = _isSendingNewsChatMessage

    fun sendNewsChatMessage(text: String) {
        if (text.trim().isEmpty()) return

        val userMsg = ChatMessage(sender = "USER", text = text)
        _newsChatMessages.value = _newsChatMessages.value + userMsg
        _isSendingNewsChatMessage.value = true

        viewModelScope.launch {
            val apiService = NvidiaApiService.create()

            val selectedTitle = _selectedNewsItem.value?.title ?: "General SEBI News"
            val selectedContent = _selectedNewsItem.value?.content ?: ""
            val selectedImpact = _selectedNewsItem.value?.impact ?: ""

            val systemInstruction = """
                You are InvestorShield's SEBI News Analyst Chatbot.
                The user is currently reading this SEBI news article:
                Title: $selectedTitle
                Summary: $selectedContent
                Action/Impact: $selectedImpact
                
                Your job is to answer the user's questions specifically in relation to this regulatory update, or general SEBI compliance guidelines.
                Break down complex legal/regulatory terms into simple, relatable advice for a retail investor.
                Remind the user of active protective measures they should take. Be helpful, professional, and clear.
            """.trimIndent()

            val nvidiaMessages = mutableListOf<NvidiaMessage>()
            nvidiaMessages.add(NvidiaMessage(role = "system", content = systemInstruction))

            var expectedRole = "user"
            _newsChatMessages.value.takeLast(10).forEach { msg ->
                val role = if (msg.sender == "USER") "user" else "assistant"
                if (role == expectedRole) {
                    nvidiaMessages.add(NvidiaMessage(role = role, content = msg.text))
                    expectedRole = if (role == "user") "assistant" else "user"
                }
            }

            val request = NvidiaChatRequest(
                model = "google/gemma-3n-e2b-it",
                messages = nvidiaMessages,
                max_tokens = 1024,
                temperature = 0.20f,
                top_p = 0.70f,
                stream = false
            )

            try {
                val authHeader = "Bearer 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"
                val response = apiService.chatCompletions(authHeader, request = request)
                val replyText = response.choices?.firstOrNull()?.message?.content
                    ?: "I'm having trouble retrieving details. Please check your network connection."

                _newsChatMessages.value = _newsChatMessages.value + ChatMessage(sender = "GEMINI", text = replyText)
            } catch (e: Exception) {
                Log.e("InvestorShieldNewsChat", "News Chat API failed", e)
                _newsChatMessages.value = _newsChatMessages.value + ChatMessage(
                    sender = "GEMINI",
                    text = "A connection error occurred. Could not reach analyst server. (Error: ${e.localizedMessage})"
                )
            } finally {
                _isSendingNewsChatMessage.value = false
            }
        }
    }

    fun clearNewsChat() {
        val selected = _selectedNewsItem.value?.title ?: "this article"
        _newsChatMessages.value = listOf(
            ChatMessage(
                sender = "GEMINI",
                text = "Analyst history cleared. Feel free to ask any other questions about $selected or other regulatory compliance policies."
            )
        )
    }

    // Fetch News dynamically using the AI
    fun fetchSebiNewsFromAI() {
        _isFetchingNews.value = true
        viewModelScope.launch {
            val apiService = NvidiaApiService.create()
            
            val systemInstruction = """
                You are a SEBI Regulatory Compliance Feed Generator. 
                Generate a list of 5 realistic, daily regulatory updates, warning circulars, or enforcement advisories issued by SEBI (Securities and Exchange Board of India) for retail stock market investors in India.
                The news should be highly relevant and realistic, styled like real circulars from June/July 2026.
                
                You MUST return ONLY a raw JSON array of objects with NO markdown formatting, NO backticks (```), and NO text wrapping.
                Each object MUST have the following keys:
                - "title": A short, catchy title (e.g., "SEBI cautions against fraudulent PMS advisory")
                - "category": String ("Circular", "Warning", "Press Release", "Advisory")
                - "date": String (formatted like "July 3, 2026")
                - "content": String (2-3 sentences explaining the technical rule or warning in user-friendly language)
                - "impact": String (1 sentence explaining what the investor should do or avoid)
                - "severity": String ("Low", "Medium", "High")
                
                Example of desired output format:
                [{"title":"SEBI warning on Telegram channels","category":"Warning","date":"July 3, 2026","content":"Details...","impact":"Action...","severity":"High"}]
            """.trimIndent()

            val request = NvidiaChatRequest(
                model = "google/gemma-3n-e2b-it",
                messages = listOf(
                    NvidiaMessage(role = "system", content = systemInstruction),
                    NvidiaMessage(role = "user", content = "Generate 5 new regulatory news updates.")
                ),
                max_tokens = 2048,
                temperature = 0.30f,
                top_p = 0.80f,
                stream = false
            )

            try {
                val authHeader = "Bearer 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"
                val response = apiService.chatCompletions(authHeader, request = request)
                val responseText = response.choices?.firstOrNull()?.message?.content
                if (!responseText.isNullOrEmpty()) {
                    var cleanText = responseText.trim()
                    if (cleanText.startsWith("```")) {
                        cleanText = cleanText.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                    }
                    
                    val jsonArray = JSONArray(cleanText)
                    val newList = mutableListOf<SebiNewsItem>()
                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        newList.add(
                            SebiNewsItem(
                                title = obj.optString("title", "SEBI News Update"),
                                category = obj.optString("category", "Circular"),
                                date = obj.optString("date", "Today"),
                                content = obj.optString("content", ""),
                                impact = obj.optString("impact", ""),
                                severity = obj.optString("severity", "Medium")
                            )
                        )
                    }
                    if (newList.isNotEmpty()) {
                        _sebiNews.value = newList
                        _selectedNewsItem.value = newList.firstOrNull()
                    }
                }
            } catch (e: Exception) {
                Log.e("InvestorShieldNews", "Failed to fetch AI news feed, using fallbacks", e)
            } finally {
                _isFetchingNews.value = false
            }
        }
    }
}
