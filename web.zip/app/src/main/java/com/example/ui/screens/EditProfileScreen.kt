package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ScanViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    viewModel: ScanViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val currentName by viewModel.userProfileName.collectAsState()
    val currentRole by viewModel.userProfileRole.collectAsState()
    val currentBio by viewModel.userProfileBio.collectAsState()

    var name by remember { mutableStateOf(currentName) }
    var role by remember { mutableStateOf(currentRole) }
    var bio by remember { mutableStateOf(currentBio) }

    var nameError by remember { mutableStateOf<String?>(null) }
    var roleError by remember { mutableStateOf<String?>(null) }
    var bioError by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    fun handleSave() {
        var isValid = true
        if (name.trim().isEmpty()) {
            nameError = "Full Name cannot be empty"
            isValid = false
        } else {
            nameError = null
        }

        if (role.trim().isEmpty()) {
            roleError = "Designation/Role cannot be empty"
            isValid = false
        } else {
            roleError = null
        }

        if (bio.trim().isEmpty()) {
            bioError = "Bio/Description cannot be empty"
            isValid = false
        } else {
            bioError = null
        }

        if (isValid) {
            isSaving = true
            viewModel.updateProfile(name, role, bio)
            Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
            onNavigateBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Edit Profile",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = PrimaryDark
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Navigate back",
                            tint = PrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceWhite,
                    scrolledContainerColor = SurfaceWhite
                ),
                modifier = Modifier.border(width = 0.5.dp, color = SlateBorder)
            )
        },
        containerColor = LightBg,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Form Header Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SlateBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Personal Information",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryDark
                        )

                        Divider(color = SlateBorder, thickness = 0.5.dp)

                        // 1. Full Name Field (Filled Style per M3 Guidelines)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Full Name",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark,
                                letterSpacing = 0.5.sp
                            )
                            TextField(
                                value = name,
                                onValueChange = {
                                    name = it
                                    if (nameError != null) nameError = null
                                },
                                placeholder = { Text("e.g. Aivo Sujith", fontSize = 14.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Person,
                                        contentDescription = "Name Icon",
                                        tint = SecondarySlate,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                singleLine = true,
                                isError = nameError != null,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xFFF8FAFC),
                                    unfocusedContainerColor = Color(0xFFF8FAFC),
                                    disabledContainerColor = Color(0xFFF1F5F9),
                                    focusedIndicatorColor = PrimaryAccent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    errorIndicatorColor = RiskHigh
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("edit_name_input")
                            )
                            nameError?.let {
                                Text(
                                    text = it,
                                    color = RiskHigh,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(start = 4.dp)
                                )
                            }
                        }

                        // 2. Designation / Role Field (Filled Style)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Designation / Role",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark,
                                letterSpacing = 0.5.sp
                            )
                            TextField(
                                value = role,
                                onValueChange = {
                                    role = it
                                    if (roleError != null) roleError = null
                                },
                                placeholder = { Text("e.g. Executive Account", fontSize = 14.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Badge,
                                        contentDescription = "Role Icon",
                                        tint = SecondarySlate,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                singleLine = true,
                                isError = roleError != null,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xFFF8FAFC),
                                    unfocusedContainerColor = Color(0xFFF8FAFC),
                                    disabledContainerColor = Color(0xFFF1F5F9),
                                    focusedIndicatorColor = PrimaryAccent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    errorIndicatorColor = RiskHigh
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("edit_role_input")
                            )
                            roleError?.let {
                                Text(
                                    text = it,
                                    color = RiskHigh,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(start = 4.dp)
                                )
                            }
                        }

                        // 3. Biography Field (Filled Style, multiline)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Biography",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark,
                                letterSpacing = 0.5.sp
                            )
                            TextField(
                                value = bio,
                                onValueChange = {
                                    bio = it
                                    if (bioError != null) bioError = null
                                },
                                placeholder = { Text("Write a brief bio...", fontSize = 14.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Info,
                                        contentDescription = "Bio Icon",
                                        tint = SecondarySlate,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                minLines = 3,
                                maxLines = 5,
                                isError = bioError != null,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xFFF8FAFC),
                                    unfocusedContainerColor = Color(0xFFF8FAFC),
                                    disabledContainerColor = Color(0xFFF1F5F9),
                                    focusedIndicatorColor = PrimaryAccent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    errorIndicatorColor = RiskHigh
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("edit_bio_input")
                            )
                            bioError?.let {
                                Text(
                                    text = it,
                                    color = RiskHigh,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(start = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Save Changes Button
                Button(
                    onClick = { handleSave() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryDark,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_profile_button"),
                    enabled = !isSaving
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Save,
                                contentDescription = "Save Icon",
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Save Changes",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
