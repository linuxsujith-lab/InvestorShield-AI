package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ScanViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: ScanViewModel,
    onNavigateToEdit: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val userName by viewModel.userProfileName.collectAsState()
    val userEmail by viewModel.userProfileEmail.collectAsState()
    val userRole by viewModel.userProfileRole.collectAsState()
    val userBio by viewModel.userProfileBio.collectAsState()
    
    val totalScans by viewModel.totalScans.collectAsState()
    val criticalThreats by viewModel.criticalThreats.collectAsState()
    val riskScore by viewModel.riskProtectionScore.collectAsState()
    val biometricEnabled by viewModel.biometricEnabled.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(PrimaryDark, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "Security Icon",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "InvestorShield",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = PrimaryDark,
                            letterSpacing = (-0.5).sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceWhite,
                    scrolledContainerColor = SurfaceWhite
                ),
                modifier = Modifier.border(width = 0.5.dp, color = SlateBorder)
            )
        },
        containerColor = LightBg,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Profile Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Avatar with green verified badge overlay
                        Box(
                            modifier = Modifier.size(90.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // Circular Avatar Frame
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .background(
                                        brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                            colors = listOf(PrimaryDark, PrimaryAccent)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                // Initials
                                val initials = userName.split(" ")
                                    .mapNotNull { it.firstOrNull()?.toString() }
                                    .take(2)
                                    .joinToString("")
                                    .uppercase()
                                
                                Text(
                                    text = initials.ifEmpty { "IS" },
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                            
                            // Verified Badge Overlay bottom-right
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .align(Alignment.BottomEnd)
                                    .offset(x = (-4).dp, y = (-4).dp)
                                    .background(Color.White, CircleShape)
                                    .padding(2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Verified,
                                    contentDescription = "Verified Account",
                                    tint = RiskLow,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }

                        // Bold Name & Email
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = userName,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = userEmail,
                                fontSize = 12.sp,
                                color = SecondarySlate
                            )
                        }

                        // Navy "★ Executive Account" Pill
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF1E3A8A), RoundedCornerShape(20.dp))
                                .padding(horizontal = 14.dp, vertical = 5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "★ $userRole",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Bio/Description (grey text)
                        Text(
                            text = userBio,
                            fontSize = 12.sp,
                            color = SecondarySlate,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Outline "Edit Profile" Button
                        OutlinedButton(
                            onClick = onNavigateToEdit,
                            border = BorderStroke(1.dp, SlateBorder),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("edit_profile_button"),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryAccent)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "Edit Profile",
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Edit Profile",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 2. Three StatCards Stacked
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Total Scans",
                        value = totalScans.toString(),
                        icon = Icons.Filled.Shield,
                        iconColor = Color(0xFF1E3A8A), // navy
                        backgroundColor = Color(0xFFEFF6FF)
                    )

                    StatCard(
                        title = "Critical Threats Found",
                        value = criticalThreats.toString(),
                        icon = Icons.Filled.Warning,
                        iconColor = RiskHigh,
                        backgroundColor = RiskHighLight
                    )

                    StatCard(
                        title = "Risk Protection Score",
                        value = "$riskScore%",
                        icon = Icons.Filled.VerifiedUser,
                        iconColor = RiskLow,
                        backgroundColor = RiskLowLight
                    )
                }

                // 3. Account Settings Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFFEFF6FF).copy(alpha = 0.5f))
                        .border(1.dp, SlateBorder, RoundedCornerShape(20.dp))
                ) {
                    // Header band
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFEFF6FF))
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Text(
                            text = "Account Settings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF1E3A8A), // navy
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Settings Rows
                    SettingsListRow(
                        title = "Security Settings",
                        subtitle = "Passwords, 2FA, Active Sessions",
                        onClick = {
                            Toast.makeText(context, "Security settings configuration opened", Toast.LENGTH_SHORT).show()
                        }
                    )

                    Divider(color = SlateBorder, thickness = 0.5.dp)

                    SettingsListRow(
                        title = "Connected Accounts",
                        subtitle = "Manage linked bank and brokerage accounts",
                        onClick = {
                            Toast.makeText(context, "Connected accounts portal opened", Toast.LENGTH_SHORT).show()
                        }
                    )

                    Divider(color = SlateBorder, thickness = 0.5.dp)

                    SettingsListRow(
                        title = "Privacy",
                        subtitle = "Data sharing and analytics preferences",
                        onClick = {
                            Toast.makeText(context, "Privacy policies and preferences", Toast.LENGTH_SHORT).show()
                        }
                    )

                    Divider(color = SlateBorder, thickness = 0.5.dp)

                    SettingsListRow(
                        title = "Notifications",
                        subtitle = "Email, SMS, and Push alerts",
                        onClick = {
                            Toast.makeText(context, "Notification preferences customized", Toast.LENGTH_SHORT).show()
                        }
                    )

                    Divider(color = SlateBorder, thickness = 0.5.dp)

                    // Biometric Login Switch Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Biometric Login",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Use FaceID or TouchID for faster access",
                                fontSize = 11.sp,
                                color = SecondarySlate
                            )
                        }
                        
                        Switch(
                            checked = biometricEnabled,
                            onCheckedChange = { isChecked ->
                                viewModel.setBiometricEnabled(isChecked)
                                val status = if (isChecked) "enabled" else "disabled"
                                Toast.makeText(context, "Biometric login $status successfully", Toast.LENGTH_SHORT).show()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = PrimaryAccent,
                                uncheckedThumbColor = SecondarySlate,
                                uncheckedTrackColor = SlateBorder
                            ),
                            modifier = Modifier.testTag("biometric_switch")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 4. Centered Logout Text-Link
                Row(
                    modifier = Modifier
                        .clickable { onLogout() }
                        .padding(12.dp)
                        .testTag("logout_link_button"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ExitToApp,
                        contentDescription = "Logout icon",
                        tint = RiskHigh,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Logout",
                        color = RiskHigh,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconColor: Color,
    backgroundColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(0.5.dp, SlateBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(backgroundColor, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = PrimaryDark
                )
            }

            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = iconColor
            )
        }
    }
}

@Composable
fun SettingsListRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = SecondarySlate
            )
        }
        
        Icon(
            imageVector = Icons.Outlined.ChevronRight,
            contentDescription = "Arrow right",
            tint = SecondarySlate,
            modifier = Modifier.size(18.dp)
        )
    }
}
