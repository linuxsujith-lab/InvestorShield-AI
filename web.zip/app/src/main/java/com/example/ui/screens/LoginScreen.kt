package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onLoginSuccess: (email: String, name: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }
    
    // Simple mock validation error states
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val coroutineScope = rememberCoroutineScope()
    var showGoogleSignInDialog by remember { mutableStateOf(false) }
    var isGoogleSigningIn by remember { mutableStateOf(false) }
    var selectedGoogleAccount by remember { mutableStateOf<String?>(null) }
    var googleScreenState by remember { mutableStateOf("PICKER") } // "PICKER" or "ADD_ACCOUNT"

    var newEmail by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var newEmailError by remember { mutableStateOf<String?>(null) }
    var newNameError by remember { mutableStateOf<String?>(null) }

    val googleAccounts = remember {
        mutableStateListOf(
            Pair("Aivo Sujith", "aivosujith@gmail.com"),
            Pair("Guest Investor", "guest.investor@gmail.com")
        )
    }

    fun handleSignIn() {
        var hasError = false
        if (email.isBlank()) {
            emailError = "Email is required"
            hasError = true
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailError = "Please enter a valid email address"
            hasError = true
        } else {
            emailError = null
        }

        if (password.isBlank()) {
            passwordError = "Password is required"
            hasError = true
        } else if (password.length < 6) {
            passwordError = "Password must be at least 6 characters"
            hasError = true
        } else {
            passwordError = null
        }

        if (!hasError) {
            isLoading = true
            // Simulate brief network delay for authenticating
            focusManager.clearFocus()
            val resolvedName = if (email.trim().lowercase() == "aivosujith@gmail.com") "Aivo Sujith" else "Investor User"
            onLoginSuccess(email, resolvedName)
        }
    }

    Scaffold(
        containerColor = LightBg,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 440.dp)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Logo & Header Block
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(PrimaryDark, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Security,
                            contentDescription = "InvestorShield Logo",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "InvestorShield",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryDark,
                            letterSpacing = (-0.75).sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Enterprise-grade financial threat intelligence",
                            fontSize = 13.sp,
                            color = SecondarySlate,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Main login form card (inspired by shadcn/ui Card style)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SlateBorder, RoundedCornerShape(20.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Welcome back",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "Enter your credentials to access your secure dashboard.",
                                fontSize = 12.sp,
                                color = SecondarySlate
                            )
                        }

                        Divider(color = SlateBorder, thickness = 1.dp)

                        // Email Field
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Email Address",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark,
                                letterSpacing = 0.5.sp
                            )
                            OutlinedTextField(
                                value = email,
                                onValueChange = {
                                    email = it
                                    if (emailError != null) emailError = null
                                },
                                placeholder = { Text("name@example.com", fontSize = 14.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Email,
                                        contentDescription = "Email",
                                        tint = SecondarySlate,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                singleLine = true,
                                isError = emailError != null,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Email,
                                    imeAction = ImeAction.Next
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PrimaryAccent,
                                    unfocusedBorderColor = SlateBorder,
                                    errorBorderColor = RiskHigh,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("username_input")
                            )
                            
                            AnimatedVisibility(
                                visible = emailError != null,
                                enter = fadeIn(),
                                exit = fadeOut()
                            ) {
                                emailError?.let {
                                    Text(
                                        text = it,
                                        color = RiskHigh,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                                    )
                                }
                            }
                        }

                        // Password Field
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Password",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryDark,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "Forgot password?",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryAccent,
                                    modifier = Modifier.clickable {
                                        // Mock forgot password feedback
                                    }
                                )
                            }
                            OutlinedTextField(
                                value = password,
                                onValueChange = {
                                    password = it
                                    if (passwordError != null) passwordError = null
                                },
                                placeholder = { Text("Enter your password", fontSize = 14.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Lock,
                                        contentDescription = "Password",
                                        tint = SecondarySlate,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                trailingIcon = {
                                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                            contentDescription = if (isPasswordVisible) "Hide Password" else "Show Password",
                                            tint = SecondarySlate,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                },
                                singleLine = true,
                                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                isError = passwordError != null,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Password,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = { handleSignIn() }
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PrimaryAccent,
                                    unfocusedBorderColor = SlateBorder,
                                    errorBorderColor = RiskHigh,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("password_input")
                            )
                            
                            AnimatedVisibility(
                                visible = passwordError != null,
                                enter = fadeIn(),
                                exit = fadeOut()
                            ) {
                                passwordError?.let {
                                    Text(
                                        text = it,
                                        color = RiskHigh,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                                    )
                                }
                            }
                        }

                        // Remember Me Checkbox
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { rememberMe = !rememberMe }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .background(
                                        color = if (rememberMe) PrimaryDark else Color.Transparent,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (rememberMe) PrimaryDark else SlateBorder,
                                        shape = RoundedCornerShape(4.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (rememberMe) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = "Checked",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Remember me on this device",
                                fontSize = 12.sp,
                                color = SecondarySlate
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Submit Button
                        Button(
                            onClick = { handleSignIn() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryDark,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("signin_button"),
                            enabled = !isLoading
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = "Sign in with Email",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // SSO Separator
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Divider(modifier = Modifier.weight(1f), color = SlateBorder, thickness = 0.5.dp)
                            Text(
                                text = "OR CONTINUE WITH",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = SecondarySlate,
                                modifier = Modifier.padding(horizontal = 8.dp),
                                letterSpacing = 1.sp
                            )
                            Divider(modifier = Modifier.weight(1f), color = SlateBorder, thickness = 0.5.dp)
                        }

                        // SSO Outlined Button (shadcn/ui style)
                        OutlinedButton(
                            onClick = {
                                focusManager.clearFocus()
                                showGoogleSignInDialog = true
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = PrimaryDark
                            ),
                            border = BorderStroke(1.dp, SlateBorder),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("google_signin_button")
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Custom vector-like simple drawing of Google "G" representation
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .background(Color(0xFFEA4335).copy(alpha = 0.1f), RoundedCornerShape(4.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "G",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFFEA4335)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Sign up with Google",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Footer section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Don't have an account? ",
                        fontSize = 12.sp,
                        color = SecondarySlate
                    )
                    Text(
                        text = "Contact Administrator",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryAccent,
                        modifier = Modifier.clickable {
                            // Mock click behavior
                        }
                    )
                }
            }
        }
    }

    if (showGoogleSignInDialog) {
        Dialog(
            onDismissRequest = {
                if (!isGoogleSigningIn) {
                    showGoogleSignInDialog = false
                    googleScreenState = "PICKER"
                }
            }
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(1.dp, SlateBorder, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (isGoogleSigningIn) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(vertical = 24.dp)
                        ) {
                            CircularProgressIndicator(
                                color = PrimaryAccent,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Signing you in...",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDark
                            )
                            Text(
                                text = "Creating your secure account environment for $selectedGoogleAccount...",
                                fontSize = 12.sp,
                                color = SecondarySlate,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else if (googleScreenState == "PICKER") {
                        // Authentic colored Google branding
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                            Text("o", color = Color(0xFFEA4335), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                            Text("o", color = Color(0xFFFBBC05), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                            Text("g", color = Color(0xFF4285F4), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                            Text("l", color = Color(0xFF34A853), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                            Text("e", color = Color(0xFFEA4335), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        }

                        Text(
                            text = "Choose an account to continue to InvestorShield",
                            fontSize = 13.sp,
                            color = SecondarySlate,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        // Render active simulated device Google accounts
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            googleAccounts.forEach { account ->
                                val (name, emailStr) = account
                                val initial = name.firstOrNull()?.toString() ?: "U"

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedGoogleAccount = emailStr
                                            isGoogleSigningIn = true
                                            coroutineScope.launch {
                                                delay(1500)
                                                showGoogleSignInDialog = false
                                                isGoogleSigningIn = false
                                                onLoginSuccess(emailStr, name)
                                            }
                                        },
                                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                                    border = BorderStroke(0.5.dp, SlateBorder),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .background(PrimaryAccent.copy(alpha = 0.1f), RoundedCornerShape(18.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = initial,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = PrimaryAccent
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = name,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = PrimaryDark
                                            )
                                            Text(
                                                text = emailStr,
                                                fontSize = 11.sp,
                                                color = SecondarySlate
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Add Another Google Account (Simulates device-account linking)
                        TextButton(
                            onClick = {
                                newEmail = ""
                                newName = ""
                                newEmailError = null
                                newNameError = null
                                googleScreenState = "ADD_ACCOUNT"
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = PrimaryAccent),
                            modifier = Modifier.testTag("use_another_account_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Use another account / Confirm Gmail ID",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Dismiss Dialog
                        TextButton(
                            onClick = { showGoogleSignInDialog = false },
                            colors = ButtonDefaults.textButtonColors(contentColor = SecondarySlate)
                        ) {
                            Text(text = "Cancel", fontSize = 12.sp)
                        }
                    } else if (googleScreenState == "ADD_ACCOUNT") {
                        // Dynamic Add Google Account / Confirm Gmail ID Screen
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                                Text("o", color = Color(0xFFEA4335), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                                Text("o", color = Color(0xFFFBBC05), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                                Text("g", color = Color(0xFF4285F4), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                                Text("l", color = Color(0xFF34A853), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                                Text("e", color = Color(0xFFEA4335), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Google Account Setup",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryDark
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Confirm or add any Gmail ID. It will display on the account picker just like on your real phone.",
                                    fontSize = 12.sp,
                                    color = SecondarySlate,
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Dynamic Name Field
                            OutlinedTextField(
                                value = newName,
                                onValueChange = {
                                    newName = it
                                    if (newNameError != null) newNameError = null
                                },
                                label = { Text("Your Name", fontSize = 12.sp) },
                                placeholder = { Text("e.g. Sujith", fontSize = 14.sp) },
                                singleLine = true,
                                isError = newNameError != null,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PrimaryAccent,
                                    unfocusedBorderColor = SlateBorder,
                                    errorBorderColor = RiskHigh
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("google_name_input")
                            )
                            newNameError?.let {
                                Text(
                                    text = it,
                                    color = RiskHigh,
                                    fontSize = 11.sp,
                                    modifier = Modifier.align(Alignment.Start)
                                )
                            }

                            // Dynamic Email Field
                            OutlinedTextField(
                                value = newEmail,
                                onValueChange = {
                                    newEmail = it
                                    if (newEmailError != null) newEmailError = null
                                },
                                label = { Text("Gmail Address", fontSize = 12.sp) },
                                placeholder = { Text("username@gmail.com", fontSize = 14.sp) },
                                singleLine = true,
                                isError = newEmailError != null,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PrimaryAccent,
                                    unfocusedBorderColor = SlateBorder,
                                    errorBorderColor = RiskHigh
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("google_email_input")
                            )
                            newEmailError?.let {
                                Text(
                                    text = it,
                                    color = RiskHigh,
                                    fontSize = 11.sp,
                                    modifier = Modifier.align(Alignment.Start)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { googleScreenState = "PICKER" }
                                ) {
                                    Text(text = "Back", color = SecondarySlate)
                                }

                                Button(
                                    onClick = {
                                        var valid = true
                                        if (newName.isBlank()) {
                                            newNameError = "Name is required"
                                            valid = false
                                        }
                                        if (newEmail.isBlank()) {
                                            newEmailError = "Google Gmail ID is required"
                                            valid = false
                                        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(newEmail).matches() || !newEmail.endsWith("@gmail.com")) {
                                            newEmailError = "Please enter a valid @gmail.com address"
                                            valid = false
                                        }

                                        if (valid) {
                                            // Add to active Google Accounts list
                                            googleAccounts.add(Pair(newName, newEmail))
                                            selectedGoogleAccount = newEmail
                                            isGoogleSigningIn = true
                                            coroutineScope.launch {
                                                delay(1500)
                                                showGoogleSignInDialog = false
                                                isGoogleSigningIn = false
                                                googleScreenState = "PICKER"
                                                onLoginSuccess(newEmail, newName)
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryAccent),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(text = "Confirm & Sign Up", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
