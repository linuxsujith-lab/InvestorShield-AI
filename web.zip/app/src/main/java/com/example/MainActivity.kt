package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.ScanViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ScanCenterScreen
import com.example.ui.screens.ReportDetailScreen
import com.example.ui.screens.ThreatIntelScreen
import com.example.ui.screens.ComplianceChatScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SebiNewsScreen
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Person
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.EditProfileScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PrimaryDark
import com.example.ui.theme.SecondarySlate
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SurfaceWhite

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val viewModel: ScanViewModel = viewModel()

                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route

                    val showBottomBar = currentRoute in listOf("dashboard", "scan", "news", "threats", "chat", "profile")

                    Scaffold(
                        bottomBar = {
                            if (showBottomBar) {
                                NavigationBar(
                                    containerColor = SurfaceWhite,
                                    tonalElevation = 0.dp,
                                    modifier = Modifier.border(width = 0.5.dp, color = SlateBorder)
                                ) {
                                    val items = listOf(
                                        Triple("dashboard", "Overview", Icons.Filled.Dashboard),
                                        Triple("scan", "Forensic", Icons.Filled.Shield),
                                        Triple("news", "SEBI News", Icons.Filled.Newspaper),
                                        Triple("threats", "Threat DB", Icons.Filled.Language),
                                        Triple("chat", "Advisor", Icons.Filled.Chat),
                                        Triple("profile", "Profile", Icons.Filled.Person)
                                    )
                                    items.forEach { (route, label, icon) ->
                                        val isSelected = currentRoute == route
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = {
                                                if (currentRoute != route) {
                                                    navController.navigate(route) {
                                                        popUpTo("dashboard") { saveState = true }
                                                        launchSingleTop = true
                                                        restoreState = true
                                                    }
                                                }
                                            },
                                            icon = {
                                                Icon(
                                                    imageVector = icon,
                                                    contentDescription = label,
                                                    tint = if (isSelected) PrimaryDark else SecondarySlate
                                                )
                                            },
                                            label = {
                                                Text(
                                                    text = label,
                                                    color = if (isSelected) PrimaryDark else SecondarySlate,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    fontSize = 11.sp
                                                )
                                            },
                                            colors = NavigationBarItemDefaults.colors(
                                                indicatorColor = SlateBorder.copy(alpha = 0.4f)
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = "login",
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable("login") {
                                LoginScreen(
                                    onLoginSuccess = { email, name ->
                                        viewModel.setLoggedInUser(email, name)
                                        navController.navigate("dashboard") {
                                            popUpTo("login") { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable("dashboard") {
                                DashboardScreen(
                                    viewModel = viewModel,
                                    onNavigateToScan = { navController.navigate("scan") },
                                    onNavigateToReport = { id -> navController.navigate("report/$id") },
                                    onNavigateToThreats = { navController.navigate("threats") },
                                    onNavigateToChat = { navController.navigate("chat") },
                                    onLogout = {
                                        navController.navigate("login") {
                                            popUpTo("dashboard") { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable("scan") {
                                ScanCenterScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { navController.popBackStack() },
                                    onScanComplete = {
                                        val lastScanId = viewModel.scanResult.value?.id
                                        viewModel.clearScanResult()
                                        if (lastScanId != null) {
                                            navController.navigate("report/$lastScanId") {
                                                popUpTo("dashboard")
                                            }
                                        } else {
                                            navController.popBackStack()
                                        }
                                    }
                                )
                            }

                            composable(
                                route = "report/{scanId}",
                                arguments = listOf(navArgument("scanId") { type = NavType.StringType })
                            ) { backStackEntry ->
                                val scanId = backStackEntry.arguments?.getString("scanId") ?: ""
                                ReportDetailScreen(
                                    scanId = scanId,
                                    viewModel = viewModel,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable("threats") {
                                ThreatIntelScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable("chat") {
                                ComplianceChatScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable("news") {
                                SebiNewsScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable("profile") {
                                ProfileScreen(
                                    viewModel = viewModel,
                                    onNavigateToEdit = { navController.navigate("profile/edit") },
                                    onLogout = {
                                        navController.navigate("login") {
                                            popUpTo("dashboard") { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable("profile/edit") {
                                EditProfileScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
